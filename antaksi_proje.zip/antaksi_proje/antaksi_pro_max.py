﻿import os
from flask import Flask, render_template_string, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta

# ========== FLASK UYGULAMASI ==========
app = Flask(__name__)
app.config['SECRET_KEY'] = 'antaksi-pro-max-2024-emre'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///antaksi_pro.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Lütfen giriş yapınız!'

# ========== DATABASE MODELLERİ ==========
class User(UserMixin, db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    user_type = db.Column(db.String(20), nullable=False, default='passenger')
    profile_pic = db.Column(db.String(200), default='default.png')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Sürücü için ek alanlar
    vehicle_model = db.Column(db.String(50))
    vehicle_plate = db.Column(db.String(20))
    vehicle_color = db.Column(db.String(20))
    driver_rating = db.Column(db.Float, default=5.0)
    total_rides = db.Column(db.Integer, default=0)
    
    # Konum ve durum
    current_lat = db.Column(db.Float)
    current_lng = db.Column(db.Float)
    is_online = db.Column(db.Boolean, default=False)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_badge_color(self):
        if self.user_type == 'passenger':
            return 'success'
        elif self.user_type == 'driver':
            return 'warning'
        else:
            return 'danger'
    
    def get_icon(self):
        if self.user_type == 'passenger':
            return '👤'
        elif self.user_type == 'driver':
            return '🚕'
        else:
            return '👑'

class Ride(db.Model):
    __tablename__ = 'ride'
    id = db.Column(db.Integer, primary_key=True)
    passenger_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    driver_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    pickup_address = db.Column(db.String(200))
    dropoff_address = db.Column(db.String(200))
    status = db.Column(db.String(20), default='requested')
    fare = db.Column(db.Float)
    distance = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

# ========== HTML TEMPLATE FONKSİYONU ==========
def render_page(content, title="Antaksi", hide_nav=False, hide_footer=False, scripts="", styles=""):
    return f'''<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - 🚖 Antaksi</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <style>
        :root {{
            --primary: #0066FF;
            --secondary: #00D4AA;
            --gradient: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            --shadow: 0 10px 30px rgba(0, 102, 255, 0.15);
        }}
        
        body {{
            background: #F8F9FA;
            font-family: 'Segoe UI', sans-serif;
        }}
        
        .antaksi-navbar {{
            background: white;
            box-shadow: var(--shadow);
        }}
        
        .antaksi-logo {{
            font-weight: 800;
            font-size: 28px;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        
        .antaksi-btn {{
            background: var(--gradient);
            border: none;
            color: white;
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
        }}
        
        .antaksi-btn:hover {{
            transform: translateY(-2px);
            box-shadow: var(--shadow);
            color: white;
        }}
        
        .antaksi-card {{
            background: white;
            border-radius: 15px;
            border: none;
            box-shadow: var(--shadow);
            transition: all 0.3s;
        }}
        
        .antaksi-card:hover {{
            transform: translateY(-5px);
        }}
        
        .stat-card {{
            background: white;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: var(--shadow);
        }}
        
        .stat-icon {{
            width: 60px;
            height: 60px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin: 0 auto 15px;
            background: var(--gradient);
            color: white;
        }}
    </style>
    
    {styles}
</head>
<body>
    <!-- Navigation -->
    {'' if hide_nav else f'''
    <nav class="navbar navbar-expand-lg navbar-light antaksi-navbar fixed-top">
        <div class="container">
            <a class="navbar-brand antaksi-logo" href="/">
                <i class="bi bi-car-front-fill me-2"></i>Antaksi
            </a>
            
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    {' '.join([
                        f'''<li class="nav-item">
                            <a class="nav-link" href="/passenger/dashboard">
                                <i class="bi bi-speedometer2 me-1"></i>Panel
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/profile">
                                <i class="bi bi-person-circle me-1"></i>Profil
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/logout">
                                <i class="bi bi-box-arrow-right me-1"></i>Çıkış
                            </a>
                        </li>''' if current_user.is_authenticated else
                        f'''<li class="nav-item">
                            <a class="nav-link" href="/">Ana Sayfa</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/login">Giriş Yap</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link antaksi-btn text-white" href="/register">
                                Kayıt Ol
                            </a>
                        </li>'''
                    ])}
                </ul>
            </div>
        </div>
    </nav>'''}
    
    <!-- Main Content -->
    <main class="{'' if hide_nav else 'pt-5 mt-4'}">
        {content}
    </main>
    
    <!-- Footer -->
    {'' if hide_footer else '''
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0">&copy; 2024 Antaksi. Tüm hakları saklıdır.</p>
        </div>
    </footer>'''}
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        setTimeout(() => {{
            document.querySelectorAll('.alert').forEach(alert => {{
                alert.style.transition = 'all 0.5s ease';
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 500);
            }});
        }}, 5000);
    </script>
    
    {scripts}
</body>
</html>'''

# ========== ROUTE'LAR ==========

@app.route('/')
def home():
    if current_user.is_authenticated:
        return redirect(f'/{current_user.user_type}/dashboard')
    
    content = '''
    <section style="background: var(--gradient); color: white; padding: 100px 0 60px;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4">Profesyonel Taksi Deneyimi</h1>
                    <p class="lead mb-4">Antaksi ile güvenli, hızlı ve konforlu seyahat edin.</p>
                    <div class="d-flex flex-wrap gap-3">
                        <a href="/register" class="antaksi-btn">
                            <i class="bi bi-lightning-charge me-2"></i>Hemen Başlayın
                        </a>
                        <a href="/login" class="antaksi-btn" style="background: rgba(255,255,255,0.1);">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Giriş Yap
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <div style="font-size: 150px;">🚖</div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="container py-5">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Neden Antaksi?</h2>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-lightning-charge"></i>
                    </div>
                    <h4>Hızlı</h4>
                    <p class="text-muted">Ortalama 3 dakikada taksi.</p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-shield-check"></i>
                    </div>
                    <h4>Güvenli</h4>
                    <p class="text-muted">Tüm sürücüler kontrol edilmiştir.</p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                    <h4>Uygun Fiyat</h4>
                    <p class="text-muted">Sabit fiyat garantisi.</p>
                </div>
            </div>
        </div>
    </section>
    '''
    
    return render_template_string(render_page(content, "Ana Sayfa"))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        flash('Zaten giriş yaptınız!', 'info')
        return redirect(f'/{current_user.user_type}/dashboard')
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            if user.is_active:
                login_user(user, remember=True)
                flash(f'Hoş geldiniz, {user.name}!', 'success')
                return redirect(f'/{user.user_type}/dashboard')
            else:
                flash('Hesabınız aktif değil!', 'danger')
        else:
            flash('Email veya şifre hatalı!', 'danger')
    
    content = '''
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="antaksi-card p-5">
                    <div class="text-center mb-5">
                        <div class="stat-icon mb-3">
                            <i class="bi bi-box-arrow-in-right"></i>
                        </div>
                        <h2 class="fw-bold">Giriş Yap</h2>
                    </div>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold">E-posta</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Şifre</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        
                        <button type="submit" class="antaksi-btn w-100 py-3 mb-3">
                            Giriş Yap
                        </button>
                        
                        <div class="text-center">
                            <p class="mb-0">
                                Hesabınız yok mu? 
                                <a href="/register" class="text-primary fw-bold">
                                    Kayıt Olun
                                </a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    '''
    
    return render_template_string(render_page(content, "Giriş Yap"))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(f'/{current_user.user_type}/dashboard')
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        name = request.form.get('name')
        phone = request.form.get('phone')
        user_type = request.form.get('user_type', 'passenger')
        
        existing = User.query.filter_by(email=email).first()
        if existing:
            flash('Bu email zaten kayıtlı!', 'danger')
            return redirect('/register')
        
        user = User(email=email, name=name, phone=phone, user_type=user_type)
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash(f'Kayıt başarılı! Hoş geldiniz, {name}!', 'success')
        login_user(user)
        return redirect(f'/{user_type}/dashboard')
    
    content = '''
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="antaksi-card p-5">
                    <div class="text-center mb-5">
                        <div class="stat-icon mb-3">
                            <i class="bi bi-person-plus"></i>
                        </div>
                        <h2 class="fw-bold">Kayıt Ol</h2>
                    </div>
                    
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Ad Soyad</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Telefon</label>
                                <input type="tel" name="phone" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">E-posta</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">Şifre</label>
                            <input type="password" name="password" class="form-control" required minlength="6">
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">Hesap Türü</label>
                            <select name="user_type" class="form-select">
                                <option value="passenger">Yolcu</option>
                                <option value="driver">Sürücü</option>
                            </select>
                        </div>
                        
                        <button type="submit" class="antaksi-btn w-100 py-3 mb-3">
                            Kayıt Ol
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    '''
    
    return render_template_string(render_page(content, "Kayıt Ol"))

@app.route('/logout')
@login_required
def logout():
    name = current_user.name
    logout_user()
    flash(f'Güle güle, {name}!', 'info')
    return redirect('/')

@app.route('/passenger/dashboard')
@login_required
def passenger_dashboard():
    if current_user.user_type != 'passenger':
        flash('Bu sayfaya erişim izniniz yok!', 'danger')
        return redirect('/')
    
    content = f'''
    <div class="container py-4">
        <div class="antaksi-card p-4 mb-4">
            <h1 class="fw-bold">Hoş Geldiniz, {current_user.name}!</h1>
            <p class="text-muted">Antaksi yolcu panelinize hoş geldiniz.</p>
        </div>
        
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-car-front"></i>
                    </div>
                    <h3>5</h3>
                    <p class="text-muted mb-0">Toplam Sürüş</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                    <h3>₺150</h3>
                    <p class="text-muted mb-0">Toplam Harcama</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-star"></i>
                    </div>
                    <h3>4.8</h3>
                    <p class="text-muted mb-0">Ortalama Puan</p>
                </div>
            </div>
        </div>
        
        <div class="antaksi-card p-4">
            <button class="antaksi-btn w-100 py-3" onclick="alert('🚖 Taksi çağrınız alındı!')">
                <i class="bi bi-telephone me-2"></i>Taksi Çağır
            </button>
        </div>
    </div>
    '''
    
    return render_template_string(render_page(content, "Yolcu Paneli"))

@app.route('/driver/dashboard')
@login_required
def driver_dashboard():
    if current_user.user_type != 'driver':
        flash('Bu sayfaya erişim izniniz yok!', 'danger')
        return redirect('/')
    
    content = f'''
    <div class="container py-4">
        <div class="antaksi-card p-4 mb-4">
            <h1 class="fw-bold">Hoş Geldiniz, {current_user.name}!</h1>
            <p class="text-muted">Antaksi sürücü panelinize hoş geldiniz.</p>
        </div>
        
        <div class="antaksi-card p-4 mb-4">
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" id="onlineToggle">
                <label class="form-check-label fw-bold" for="onlineToggle">Çevrimiçi Durumu</label>
            </div>
        </div>
        
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                    <h3>₺1250</h3>
                    <p class="text-muted mb-0">Toplam Kazanç</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-check-circle"></i>
                    </div>
                    <h3>42</h3>
                    <p class="text-muted mb-0">Tamamlanan Sürüş</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="bi bi-star"></i>
                    </div>
                    <h3>4.8/5</h3>
                    <p class="text-muted mb-0">Ortalama Puan</p>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        document.getElementById('onlineToggle').addEventListener('change', function() {{
            alert(this.checked ? 'Çevrimiçi oldunuz!' : 'Çevrimdışı oldunuz!');
        }});
    </script>
    '''
    
    return render_template_string(render_page(content, "Sürücü Paneli"))

@app.route('/profile')
@login_required
def profile():
    content = f'''
    <div class="container py-4">
        <div class="antaksi-card p-4">
            <h3 class="fw-bold mb-4">Profil Bilgileri</h3>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label text-muted">Ad Soyad</label>
                    <div class="form-control">{current_user.name}</div>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label text-muted">E-posta</label>
                    <div class="form-control">{current_user.email}</div>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label text-muted">Telefon</label>
                    <div class="form-control">{current_user.phone}</div>
                </div>
                
                <div class="col-md-6 mb-3">
                    <label class="form-label text-muted">Üyelik Tarihi</label>
                    <div class="form-control">{current_user.created_at.strftime('%d.%m.%Y')}</div>
                </div>
            </div>
        </div>
    </div>
    '''
    
    return render_template_string(render_page(content, "Profilim"))

# ========== BAŞLATMA ==========
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Test kullanıcılarını oluştur
        test_users = [
            ('emre@antaksi.com', 'emre123', 'Emre Yolcu', '05551112233', 'passenger'),
            ('emre321@antaksi.com', 'emre321', 'Emre Sürücü', '05554445566', 'driver'),
        ]
        
        for email, password, name, phone, user_type in test_users:
            if not User.query.filter_by(email=email).first():
                user = User(email=email, name=name, phone=phone, user_type=user_type)
                user.set_password(password)
                db.session.add(user)
        
        db.session.commit()
        print("✅ Database ve test kullanıcıları hazır!")
    
    print("🚖 ANTAKSİ PRO MAX ÇALIŞIYOR...")
    print("🌐 http://127.0.0.1:5000")
    print("👤 emre@antaksi.com / emre123")
    print("🚕 emre321@antaksi.com / emre321")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
