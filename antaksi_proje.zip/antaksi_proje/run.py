﻿from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'antaksi-2024-secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///antaksi_temp.db'  # 📍 DEĞİŞTİ
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True)
    password_hash = db.Column(db.String(128))
    name = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    user_type = db.Column(db.String(20), default='passenger')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

@app.route('/')
def index():
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>🚖 Antaksi</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
            .card { border-radius: 20px; }
            .btn-primary { background: linear-gradient(to right, #667eea, #764ba2); border: none; }
        </style>
    </head>
    <body class="d-flex align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card shadow-lg p-5">
                        <div class="text-center mb-4">
                            <h1 class="display-4">🚖</h1>
                            <h2 class="text-primary fw-bold">Antaksi</h2>
                            <p class="text-muted">Profesyonel Taksi Hizmeti</p>
                        </div>
                        <div class="text-center">
                            <a href="/login" class="btn btn-primary btn-lg px-5 py-3 me-3">
                                <i class="bi bi-box-arrow-in-right"></i> Giriş Yap
                            </a>
                            <a href="/register" class="btn btn-outline-primary btn-lg px-5 py-3">
                                <i class="bi bi-person-plus"></i> Kayıt Ol
                            </a>
                        </div>
                        <div class="mt-5 text-center">
                            <h5>Özellikler:</h5>
                            <div class="row mt-3">
                                <div class="col-4"><i class="bi bi-lightning"></i> Hızlı</div>
                                <div class="col-4"><i class="bi bi-shield-check"></i> Güvenli</div>
                                <div class="col-4"><i class="bi bi-phone"></i> Mobil</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    '''

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Test girişi
        return '''
        <div class="container mt-5">
            <div class="alert alert-success">
                <h4>✅ Giriş Başarılı!</h4>
                <p>Test modunda çalışıyorsunuz.</p>
                <a href="/" class="btn btn-primary">Ana Sayfa</a>
            </div>
        </div>
        '''
    
    return '''
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0"><i class="bi bi-box-arrow-in-right"></i> Giriş Yap</h4>
                    </div>
                    <div class="card-body p-4">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" placeholder="ornek@email.com" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Şifre</label>
                                <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100 py-2">Giriş Yap</button>
                        </form>
                        <div class="mt-3 text-center">
                            <a href="/register">Hesabınız yok mu? Kayıt Olun</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    '''

@app.route('/register')
def register():
    return '''
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-success text-white">
                        <h4 class="mb-0"><i class="bi bi-person-plus"></i> Kayıt Ol</h4>
                    </div>
                    <div class="card-body p-4">
                        <p class="text-muted">Kayıt sistemi yakında aktif olacak.</p>
                        <p>Şu anda test modundayız.</p>
                        <div class="text-center">
                            <a href="/login" class="btn btn-outline-primary">Giriş Sayfasına Dön</a>
                            <a href="/" class="btn btn-secondary ms-2">Ana Sayfa</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    '''

# Database'i oluştur
with app.app_context():
    try:
        db.create_all()
        print("✅ Database oluşturuldu: antaksi_temp.db")
    except Exception as e:
        print(f"⚠️  Database hatası: {e}")
        print("📝 Database olmadan devam ediliyor...")

if __name__ == '__main__':
    print("="*60)
    print("🚖 ANTAKSİ TAKSİ UYGULAMASI - ÇALIŞIYOR!")
    print("🌐 http://127.0.0.1:5000")
    print("📱 Telefondan erişim için aynı WiFi'de olun")
    print("="*60)
    app.run(debug=True, host='0.0.0.0', port=5000)
