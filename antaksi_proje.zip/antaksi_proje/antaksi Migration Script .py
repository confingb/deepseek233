# migrate_db.py - Güncellenmiş versiyon
"""
Antaksi SQLite migration script - v2.0

Bu script, mevcut veritabanını yeni şemaya uygun hale getirir.
Tüm yeni tabloları ve kolonları ekler, varsayılan verileri oluşturur.
"""

from __future__ import annotations

import sqlite3
import json
from pathlib import Path
from datetime import datetime, timedelta
import uuid

def detect_db() -> Path:
    """Bulabildiği ilk *.secure.db dosyasını döndürür."""
    here = Path(".").resolve()
    
    # Öncelikli dosya
    preferred = here / "antaksi_secure_api.secure.db"
    if preferred.exists():
        return preferred
    
    # Alternatifler
    candidates = list(here.glob("*.secure.db"))
    if len(candidates) == 1:
        return candidates[0]
    elif len(candidates) > 1:
        # En son değiştirilen
        candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return candidates[0]
    
    # Yeni dosya oluştur
    return preferred

def column_exists(cursor: sqlite3.Cursor, table: str, column: str) -> bool:
    """Bir tabloda kolonun var olup olmadığını kontrol eder."""
    try:
        cursor.execute(f"PRAGMA table_info({table})")
        columns = [row[1] for row in cursor.fetchall()]
        return column in columns
    except sqlite3.OperationalError:
        return False

def table_exists(cursor: sqlite3.Cursor, table: str) -> bool:
    """Tablonun var olup olmadığını kontrol eder."""
    cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (table,)
    )
    return cursor.fetchone() is not None

def create_table_if_not_exists(cursor: sqlite3.Cursor, table_name: str, ddl: str):
    """Tablo yoksa oluştur."""
    if not table_exists(cursor, table_name):
        cursor.execute(ddl)
        print(f"✓ Tablo oluşturuldu: {table_name}")
        return True
    return False

def add_column_if_not_exists(cursor: sqlite3.Cursor, table: str, column: str, ddl: str):
    """Kolon yoksa ekle."""
    if not column_exists(cursor, table, column):
        cursor.execute(f"ALTER TABLE {table} ADD COLUMN {ddl}")
        print(f"✓ Kolon eklendi: {table}.{column}")
        return True
    return False

def migrate_users_table(cursor: sqlite3.Cursor):
    """Users tablosunu güncelle."""
    changes = False
    
    # Yeni kolonlar
    new_columns = [
        ("email", "email TEXT UNIQUE"),
        ("phone", "phone TEXT UNIQUE"),
        ("wallet_balance", "wallet_balance REAL NOT NULL DEFAULT 0.0"),
        ("rating", "rating REAL DEFAULT 5.0"),
        ("total_rides", "total_rides INTEGER DEFAULT 0"),
        ("created_at", "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP"),
        ("last_login", "last_login TEXT"),
        ("profile_pic", "profile_pic TEXT"),
        ("is_banned", "is_banned INTEGER NOT NULL DEFAULT 0"),
        ("ban_reason", "ban_reason TEXT")
    ]
    
    for col_name, ddl in new_columns:
        changes |= add_column_if_not_exists(cursor, "users", col_name, ddl)
    
    # Eski kolonları koru, gerekirse varsayılan değer ata
    if column_exists(cursor, "users", "is_active"):
        # Mevcut kullanıcılar için is_active değerini koru
        pass
    else:
        cursor.execute("ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1")
        changes = True
    
    return changes

def migrate_drivers_table(cursor: sqlite3.Cursor):
    """Drivers tablosunu güncelle."""
    changes = False
    
    # Yeni kolonlar
    new_columns = [
        ("license_number", "license_number TEXT UNIQUE"),
        ("vehicle_type", "vehicle_type TEXT NOT NULL DEFAULT 'standard'"),
        ("vehicle_model", "vehicle_model TEXT"),
        ("vehicle_color", "vehicle_color TEXT"),
        ("plate_number", "plate_number TEXT UNIQUE"),
        ("capacity", "capacity INTEGER DEFAULT 4"),
        ("base_fare", "base_fare REAL DEFAULT 10.0"),
        ("min_fare", "min_fare REAL DEFAULT 20.0"),
        ("rating", "rating REAL DEFAULT 5.0"),
        ("total_rides", "total_rides INTEGER DEFAULT 0"),
        ("earnings_total", "earnings_total REAL DEFAULT 0.0"),
        ("documents_verified", "documents_verified INTEGER DEFAULT 0"),
        ("online", "online INTEGER DEFAULT 1"),
        ("region_center_lat", "region_center_lat REAL"),
        ("region_center_lon", "region_center_lon REAL"),
        ("region_radius_km", "region_radius_km REAL")
    ]
    
    for col_name, ddl in new_columns:
        changes |= add_column_if_not_exists(cursor, "drivers", col_name, ddl)
    
    return changes

def migrate_rides_table(cursor: sqlite3.Cursor):
    """Rides tablosunu güncelle."""
    changes = False
    
    # Yeni kolonlar
    new_columns = [
        ("vehicle_type", "vehicle_type TEXT NOT NULL DEFAULT 'standard'"),
        ("start_address", "start_address TEXT NOT NULL DEFAULT ''"),
        ("end_address", "end_address TEXT NOT NULL DEFAULT ''"),
        ("duration_minutes", "duration_minutes REAL"),
        ("base_fare", "base_fare REAL NOT NULL DEFAULT 10.0"),
        ("commission_rate", "commission_rate REAL NOT NULL DEFAULT 0.1"),
        ("commission_amount", "commission_amount REAL NOT NULL DEFAULT 0.0"),
        ("final_price", "final_price REAL NOT NULL DEFAULT 0.0"),
        ("status", "status TEXT NOT NULL DEFAULT 'pending'"),
        ("payment_method", "payment_method TEXT"),
        ("payment_status", "payment_status TEXT DEFAULT 'pending'"),
        ("scheduled_time", "scheduled_time TEXT"),
        ("actual_start_time", "actual_start_time TEXT"),
        ("actual_end_time", "actual_end_time TEXT"),
        ("cancelled_by", "cancelled_by TEXT"),
        ("cancellation_reason", "cancellation_reason TEXT"),
        ("route_polyline", "route_polyline TEXT")
    ]
    
    for col_name, ddl in new_columns:
        changes |= add_column_if_not_exists(cursor, "rides", col_name, ddl)
    
    return changes

def create_new_tables(cursor: sqlite3.Cursor):
    """Yeni tabloları oluştur."""
    created = False
    
    # User profiles
    created |= create_table_if_not_exists(cursor, "user_profiles", """
        CREATE TABLE user_profiles (
            user_id TEXT PRIMARY KEY,
            date_of_birth TEXT,
            gender TEXT,
            preferences TEXT,
            emergency_contact TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    
    # Driver documents
    created |= create_table_if_not_exists(cursor, "driver_documents", """
        CREATE TABLE driver_documents (
            id TEXT PRIMARY KEY,
            driver_id TEXT NOT NULL,
            document_type TEXT NOT NULL,
            document_url TEXT NOT NULL,
            verified INTEGER DEFAULT 0,
            verified_by TEXT,
            verified_at TEXT,
            expiry_date TEXT,
            FOREIGN KEY(driver_id) REFERENCES drivers(user_id)
        )
    """)
    
    # Ride waypoints
    created |= create_table_if_not_exists(cursor, "ride_waypoints", """
        CREATE TABLE ride_waypoints (
            id TEXT PRIMARY KEY,
            ride_id TEXT NOT NULL,
            sequence INTEGER NOT NULL,
            lat REAL NOT NULL,
            lon REAL NOT NULL,
            address TEXT,
            FOREIGN KEY(ride_id) REFERENCES rides(id)
        )
    """)
    
    # Payments
    created |= create_table_if_not_exists(cursor, "payments", """
        CREATE TABLE payments (
            id TEXT PRIMARY KEY,
            ride_id TEXT NOT NULL,
            customer_id TEXT NOT NULL,
            driver_id TEXT NOT NULL,
            amount REAL NOT NULL,
            commission_amount REAL NOT NULL,
            payment_method TEXT NOT NULL,
            transaction_id TEXT UNIQUE,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL,
            completed_at TEXT,
            refund_amount REAL DEFAULT 0.0,
            notes TEXT,
            FOREIGN KEY(ride_id) REFERENCES rides(id),
            FOREIGN KEY(customer_id) REFERENCES customers(user_id),
            FOREIGN KEY(driver_id) REFERENCES drivers(user_id)
        )
    """)
    
    # Ratings
    created |= create_table_if_not_exists(cursor, "ratings", """
        CREATE TABLE ratings (
            id TEXT PRIMARY KEY,
            ride_id TEXT NOT NULL,
            from_user_id TEXT NOT NULL,
            to_user_id TEXT NOT NULL,
            rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
            comment TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(ride_id) REFERENCES rides(id),
            FOREIGN KEY(from_user_id) REFERENCES users(id),
            FOREIGN KEY(to_user_id) REFERENCES users(id)
        )
    """)
    
    # Promotions
    created |= create_table_if_not_exists(cursor, "promotions", """
        CREATE TABLE promotions (
            id TEXT PRIMARY KEY,
            code TEXT UNIQUE NOT NULL,
            description TEXT,
            discount_type TEXT NOT NULL,
            discount_value REAL NOT NULL,
            min_order_amount REAL DEFAULT 0.0,
            max_discount REAL,
            valid_from TEXT NOT NULL,
            valid_until TEXT NOT NULL,
            usage_limit INTEGER,
            times_used INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            created_by TEXT,
            created_at TEXT NOT NULL
        )
    """)
    
    # User addresses
    created |= create_table_if_not_exists(cursor, "user_addresses", """
        CREATE TABLE user_addresses (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            title TEXT NOT NULL,
            address TEXT NOT NULL,
            lat REAL NOT NULL,
            lon REAL NOT NULL,
            is_default INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    
    # Driver applications (güncellenmiş)
    created |= create_table_if_not_exists(cursor, "driver_applications", """
        CREATE TABLE driver_applications (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            vehicle_type TEXT NOT NULL,
            vehicle_model TEXT,
            vehicle_year INTEGER,
            license_number TEXT,
            experience_years INTEGER,
            price_per_km REAL NOT NULL,
            lat REAL NOT NULL,
            lon REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            notes TEXT,
            reviewed_by TEXT,
            reviewed_at TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    
    # Notifications
    created |= create_table_if_not_exists(cursor, "notifications", """
        CREATE TABLE notifications (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            notification_type TEXT NOT NULL,
            is_read INTEGER DEFAULT 0,
            related_id TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    
    # Settings (güncellenmiş)
    created |= create_table_if_not_exists(cursor, "settings", """
        CREATE TABLE settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            description TEXT,
            updated_at TEXT NOT NULL,
            updated_by TEXT
        )
    """)
    
    # API logs
    created |= create_table_if_not_exists(cursor, "api_logs", """
        CREATE TABLE api_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            endpoint TEXT NOT NULL,
            ip_address TEXT,
            user_agent TEXT,
            timestamp TEXT NOT NULL,
            response_time_ms INTEGER
        )
    """)
    
    return created

def seed_default_data(cursor: sqlite3.Cursor):
    """Varsayılan verileri ekle."""
    now = datetime.now().isoformat()
    added = False
    
    # Settings
    default_settings = [
        ("commission", "0.1", "Platform komisyon oranı"),
        ("min_fare", "20.0", "Minimum yolculuk ücreti"),
        ("base_fare", "10.0", "Temel açılış ücreti"),
        ("price_per_km_standard", "30.0", "Standart araç km başı ücret"),
        ("price_per_km_comfort", "40.0", "Confort araç km başı ücret"),
        ("price_per_km_premium", "50.0", "Premium araç km başı ücret"),
        ("surge_enabled", "1", "Dinamik fiyatlandırma aktif"),
        ("max_surge_multiplier", "2.5", "Maksimum fiyat çarpanı"),
        ("driver_search_radius_km", "10.0", "Sürücü arama yarıçapı"),
        ("ride_timeout_minutes", "5", "Sürücü kabul zaman aşımı"),
        ("cancel_penalty_user", "5.0", "Kullanıcı iptal cezası"),
        ("cancel_penalty_driver", "10.0", "Sürücü iptal cezası"),
    ]
    
    for key, value, description in default_settings:
        cursor.execute(
            """
            INSERT OR IGNORE INTO settings (key, value, description, updated_at, updated_by)
            VALUES (?, ?, ?, ?, ?)
            """,
            (key, value, description, now, "system")
        )
        if cursor.rowcount > 0:
            added = True
    
    # Default admin if not exists
    cursor.execute("SELECT id FROM users WHERE role = 'admin'")
    if not cursor.fetchone():
        from antaksi_secure_api import hash_password
        admin_hash = hash_password("Admin@123")
        cursor.execute(
            """
            INSERT INTO users (id, email, name, password_hash, role, is_active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            ("admin@antaksi.com", "admin@antaksi.com", "Sistem Yöneticisi", 
             admin_hash, "admin", 1, now)
        )
        added = True
    
    # Sample promotions
    sample_promotions = [
        ("WELCOME10", "Hoş geldin indirimi", "percentage", 10.0, 0.0, None, 
         now, (datetime.now() + timedelta(days=30)).isoformat(), 100, 0, 1, "system"),
        ("FIRSTRIDE", "İlk yolculuk indirimi", "fixed", 20.0, 0.0, 20.0,
         now, (datetime.now() + timedelta(days=365)).isoformat(), 1000, 0, 1, "system"),
    ]
    
    for promo in sample_promotions:
        cursor.execute(
            """
            INSERT OR IGNORE INTO promotions 
            (id, code, description, discount_type, discount_value, min_order_amount, 
             max_discount, valid_from, valid_until, usage_limit, times_used, is_active, created_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (str(uuid.uuid4()), *promo, now)
        )
        if cursor.rowcount > 0:
            added = True
    
    return added

def backup_database(original_path: Path) -> Path:
    """Veritabanını yedekle."""
    backup_path = original_path.with_suffix(".backup.db")
    
    import shutil
    shutil.copy2(original_path, backup_path)
    
    print(f"✓ Veritabanı yedeklendi: {backup_path.name}")
    return backup_path

def main():
    """Ana migration fonksiyonu."""
    print("=" * 60)
    print("ANTARTAXI Veritabanı Migration Script - v2.0")
    print("=" * 60)
    
    # Veritabanını bul
    db_path = detect_db()
    print(f"\nVeritabanı: {db_path.name}")
    
    if not db_path.exists():
        print("❌ Veritabanı bulunamadı. Önce sunucuyu çalıştırın.")
        return
    
    # Yedek oluştur
    backup_path = backup_database(db_path)
    
    # Veritabanına bağlan
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    
    try:
        cursor = conn.cursor()
        
        print("\nMevcut tablolar kontrol ediliyor...")
        
        # Mevcut tabloları güncelle
        changes = False
        
        if table_exists(cursor, "users"):
            print("→ users tablosu güncelleniyor...")
            changes |= migrate_users_table(cursor)
        
        if table_exists(cursor, "drivers"):
            print("→ drivers tablosu güncelleniyor...")
            changes |= migrate_drivers_table(cursor)
        
        if table_exists(cursor, "rides"):
            print("→ rides tablosu güncelleniyor...")
            changes |= migrate_rides_table(cursor)
        
        # Yeni tablolar oluştur
        print("\nYeni tablolar oluşturuluyor...")
        changes |= create_new_tables(cursor)
        
        # Varsayılan verileri ekle
        print("\nVarsayılan veriler ekleniyor...")
        changes |= seed_default_data(cursor)
        
        # Değişiklikleri kaydet
        conn.commit()
        
        print("\n" + "=" * 60)
        if changes:
            print("✅ Migration başarıyla tamamlandı!")
            print(f"✓ Yedek dosyası: {backup_path.name}")
            print("✓ Tüm yeni tablolar ve kolonlar eklendi")
            print("✓ Varsayılan veriler oluşturuldu")
        else:
            print("ℹ️  Veritabanı zaten güncel, herhangi bir değişiklik yapılmadı.")
        
        print("\nMigration işlemi tamamlandı.")
        print("Sunucuyu yeniden başlatmanız önerilir.")
        
    except Exception as e:
        conn.rollback()
        print(f"\n❌ Migration hatası: {e}")
        print(f"Veritabanı yedekten geri yüklenebilir: {backup_path.name}")
        raise
    finally:
        conn.close()

if __name__ == "__main__":
    main()