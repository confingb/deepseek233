﻿import os
from flask import Flask, render_template_string, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

# ========== FLASK UYGULAMASI ==========
app = Flask(__name__)
app.config['SECRET_KEY'] = 'antaksi-final-gizli-anahtar-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///antaksi_users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# ========== DATABASE MODELLERİ ==========
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True)
    password_hash = db.Column(db.String(128))
    name = db.Column(db.String(100))
    phone = db.Column(db.String(20))
    user_type = db.Column(db.String(20))  # passenger, driver, admin
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

# ========== TÜM HTML KODLARI ==========
def get_base_html(content="", title="Antaksi", hide_nav=False, hide_footer=False):
    return f'''
    <!DOCTYPE html>
    <html lang="tr" data-bs-theme="light">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <title>{title} - Antaksi</title>
        
        <!-- Bootstrap 5 -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
        
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        
        <!-- Custom CSS -->
        <style>
            :root {{
                --primary: #0066FF;
                --primary-dark: #0052D4;
                --secondary: #00D4AA;
                --dark: #1A1A2E;
                --light: #F8F9FA;
                --gradient: linear-gradient(135deg, #0066FF 0%, #00D4AA 100%);
                --shadow: 0 10px 30px rgba(0, 102, 255, 0.15);
            }}
            
            * {{
                font-family: 'Poppins', sans-serif;
            }}
            
            body {{
                background: var(--light);
                color: var(--dark);
                min-height: 100vh;
                overflow-x: hidden;
            }}
            
            .antaksi-navbar {{
                background: white;
                box-shadow: 0 4px 20px rgba(0,0,0,0.08);
                padding: 15px 0;
            }}
            
            .antaksi-logo {{
                font-weight: 700;
                font-size: 28px;
                background: var(--gradient);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
            }}
            
            .antaksi-card {{
                background: white;
                border-radius: 20px;
                border: none;
                box-shadow: var(--shadow);
                transition: transform 0.3s ease;
            }}
            
            .antaksi-card:hover {{
                transform: translateY(-5px);
            }}
            
            .antaksi-btn {{
                background: var(--gradient);
                border: none;
                color: white;
                padding: 12px 30px;
                border-radius: 12px;
                font-weight: 500;
                transition: all 0.3s ease;
            }}
            
            .antaksi-btn:hover {{
                transform: translateY(-2px);
                box-shadow: 0 8px 20px rgba(0, 102, 255, 0.25);
                color: white;
            }}
            
            .antaksi-btn-outline {{
                background: transparent;
                border: 2px solid var(--primary);
                color: var(--primary);
            }}
            
            .antaksi-btn-outline:hover {{
                background: var(--primary);
                color: white;
            }}
            
            .form-control-antaksi {{
                border: 2px solid #E8EEF3;
                border-radius: 12px;
                padding: 14px 20px;
                font-size: 16px;
                transition: all 0.3s ease;
            }}
            
            .form-control-antaksi:focus {{
                border-color: var(--primary);
                box-shadow: 0 0 0 3px rgba(0, 102, 255, 0.1);
            }}
            
            .user-badge {{
                display: inline-block;
                padding: 6px 15px;
                border-radius: 20px;
                font-size: 14px;
                font-weight: 500;
            }}
            
            .badge-passenger {{
                background: rgba(0, 212, 170, 0.1);
                color: var(--secondary);
            }}
            
            .badge-driver {{
                background: rgba(255, 193, 7, 0.1);
                color: #FFC107;
            }}
            
            .badge-admin {{
                background: rgba(220, 53, 69, 0.1);
                color: #DC3545;
            }}
            
            .hero-section {{
                background: var(--gradient);
                color: white;
                padding: 100px 0;
                border-radius: 0 0 40px 40px;
                margin-bottom: 60px;
            }}
            
            .feature-icon {{
                width: 70px;
                height: 70px;
                background: rgba(255, 255, 255, 0.2);
                border-radius: 20px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 30px;
                margin: 0 auto 20px;
            }}
            
            .login-container {{
                min-height: 100vh;
                display: flex;
                align-items: center;
                background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            }}
            
            .login-card {{
                border-radius: 25px;
                overflow: hidden;
            }}
            
            .login-left {{
                background: var(--gradient);
                color: white;
                padding: 50px;
                display: flex;
                flex-direction: column;
                justify-content: center;
            }}
            
            .user-type-selector .card {{
                border: 2px solid transparent;
                cursor: pointer;
                transition: all 0.3s ease;
            }}
            
            .user-type-selector .card:hover {{
                border-color: var(--primary);
            }}
            
            .user-type-selector .card.active {{
                border-color: var(--primary);
                background: rgba(0, 102, 255, 0.05);
            }}
            
            .floating-alert {{
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 9999;
                animation: slideIn 0.5s ease;
            }}
            
            @keyframes slideIn {{
                from {{
                    transform: translateX(100%);
                    opacity: 0;
                }}
                to {{
                    transform: translateX(0);
                    opacity: 1;
                }}
            }}
        </style>
    </head>
    <body>
        <!-- Flash Messages -->
        {' '.join([f'''<div class="floating-alert alert alert-{cat} alert-dismissible fade show" role="alert">
            {msg}<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>'''
            for cat, msg in getattr(app, 'flash_messages', [])])}
        
        <!-- Navigation -->
        {'' if hide_nav else f'''
        <nav class="navbar navbar-expand-lg antaksi-navbar fixed-top">
            <div class="container">
                <a class="navbar-brand antaksi-logo" href="/">
                    <i class="bi bi-car-front-fill me-2"></i>Antaksi
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        {' '.join([
                            f'''<li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                                    <div class="me-2">
                                        <strong>{current_user.name}</strong>
                                        <div>
                                            <span class="user-badge badge-{current_user.user_type}">
                                                {"🧑 Yolcu" if current_user.user_type == "passenger" else "🚕 Sürücü" if current_user.user_type == "driver" else "👑 Admin"}
                                            </span>
                                        </div>
                                    </div>
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="/{'passenger/dashboard' if current_user.user_type == 'passenger' else 'driver/dashboard' if current_user.user_type == 'driver' else 'admin/dashboard'}">
                                        <i class="bi bi-{'speedometer2' if current_user.user_type == 'passenger' else 'steering-wheel' if current_user.user_type == 'driver' else 'shield-check'}"></i>
                                        {'Yolcu' if current_user.user_type == 'passenger' else 'Sürücü' if current_user.user_type == 'driver' else 'Admin'} Paneli
                                    </a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="/logout"><i class="bi bi-box-arrow-right"></i> Çıkış Yap</a></li>
                                </ul>
                            </li>''' if current_user.is_authenticated else
                            '''<li class="nav-item"><a class="nav-link" href="/"><i class="bi bi-house"></i> Ana Sayfa</a></li>
                            <li class="nav-item"><a class="nav-link" href="/login"><i class="bi bi-box-arrow-in-right"></i> Giriş</a></li>
                            <li class="nav-item"><a class="nav-link" href="/register"><i class="bi bi-person-plus"></i> Kayıt</a></li>'''
                        ])}
                    </ul>
                </div>
            </div>
        </nav>'''}
        
        <!-- Main Content -->
        <main class="{'' if hide_nav else 'pt-5 mt-4'}">
            {content}
        </main>
        
        <!-- Footer -->
        {'' if hide_footer else '''
        <footer class="bg-dark text-white py-5 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <h3 class="antaksi-logo mb-3">Antaksi</h3>
                        <p class="text-light">Profesyonel, güvenli ve hızlı taksi hizmeti. Her zaman, her yerde.</p>
                    </div>
                    <div class="col-lg-8 text-end">
                        <p class="text-white-50 mb-0">&copy; 2024 Antaksi. Tüm hakları saklıdır.</p>
                    </div>
                </div>
            </div>
        </footer>'''}
        
        <!-- Scripts -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script>
            // Auto-dismiss alerts
            setTimeout(() => {{
                document.querySelectorAll('.floating-alert').forEach(alert => {{
                    alert.remove();
                }});
            }}, 5000);
        </script>
    </body>
    </html>
    '''

# ========== ROUTE'LAR ==========
@app.route('/')
def home():
    content = '''
    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4">Profesyonel Taksi Hizmeti</h1>
                    <p class="lead mb-4 opacity-90">Antaksi ile güvenli, hızlı ve konforlu seyahat edin.</p>
                    <div class="d-flex flex-wrap gap-3">
    '''
    
    if not current_user.is_authenticated:
        content += '''
                        <a href="/register" class="antaksi-btn">
                            <i class="bi bi-person-plus me-2"></i>Hemen Başlayın
                        </a>
                        <a href="/login" class="antaksi-btn antaksi-btn-outline">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Giriş Yap
                        </a>
        '''
    else:
        if current_user.user_type == 'passenger':
            content += f'''
                        <a href="/passenger/dashboard" class="antaksi-btn">
                            <i class="bi bi-geo-alt me-2"></i>Taksi Çağır
                        </a>
            '''
        elif current_user.user_type == 'driver':
            content += f'''
                        <a href="/driver/dashboard" class="antaksi-btn">
                            <i class="bi bi-steering-wheel me-2"></i>Sürüşe Başla
                        </a>
            '''
        else:
            content += f'''
                        <a href="/admin/dashboard" class="antaksi-btn">
                            <i class="bi bi-shield-check me-2"></i>Admin Paneli
                        </a>
            '''
    
    content += '''
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <div class="position-relative">
                        <div class="feature-icon" style="background: rgba(255,255,255,0.3);">
                            <i class="bi bi-car-front-fill"></i>
                        </div>
                        <h3 class="mt-3">500+ Aktif Sürücü</h3>
                        <p class="opacity-90">Şehir genelinde hizmet veriyoruz</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Features -->
    <section class="container py-5">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Neden Antaksi?</h2>
            <p class="text-muted">Profesyonel taksi deneyiminin en iyisi</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="antaksi-card p-4 text-center h-100">
                    <div class="feature-icon bg-primary bg-opacity-10 text-primary">
                        <i class="bi bi-lightning-charge"></i>
                    </div>
                    <h4 class="mt-3">Hızlı</h4>
                    <p class="text-muted">Ortalama 3 dakikada taksi.</p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="antaksi-card p-4 text-center h-100">
                    <div class="feature-icon bg-success bg-opacity-10 text-success">
                        <i class="bi bi-shield-check"></i>
                    </div>
                    <h4 class="mt-3">Güvenli</h4>
                    <p class="text-muted">Tüm sürücüler kontrol edilmiştir.</p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="antaksi-card p-4 text-center h-100">
                    <div class="feature-icon bg-warning bg-opacity-10 text-warning">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                    <h4 class="mt-3">Uygun Fiyat</h4>
                    <p class="text-muted">Sabit fiyat garantisi.</p>
                </div>
            </div>
        </div>
    </section>
    '''
    
    if not current_user.is_authenticated:
        content += '''
    <!-- CTA Section -->
    <section class="container py-5">
        <div class="antaksi-card p-5 text-center" style="background: var(--gradient); color: white;">
            <h2 class="fw-bold mb-4">Hemen Deneyin!</h2>
            <p class="lead mb-4 opacity-90">Antaksi'ye katılın ve profesyonel taksi deneyimini yaşayın.</p>
            <a href="/register" class="antaksi-btn" style="background: white; color: var(--primary);">
                <i class="bi bi-person-plus me-2"></i>Ücretsiz Kayıt Ol
            </a>
        </div>
    </section>
        '''
    
    return render_template_string(get_base_html(content, "Ana Sayfa"))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        flash('Zaten giriş yaptınız!', 'info')
        return redirect('/')
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            login_user(user, remember=True)
            flash(f'Hoş geldiniz, {user.name}! 🎉', 'success')
            
            if user.user_type == 'passenger':
                return redirect('/passenger/dashboard')
            elif user.user_type == 'driver':
                return redirect('/driver/dashboard')
            else:
                return redirect('/admin/dashboard')
        else:
            flash('Email veya şifre hatalı!', 'danger')
            return redirect('/login')
    
    # Login sayfası içeriği
    login_content = '''
    <div class="login-container">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="login-card antaksi-card">
                        <div class="row g-0">
                            <!-- Left Side - Welcome -->
                            <div class="col-lg-6 login-left">
                                <div class="text-center mb-5">
                                    <div class="display-1 mb-3">
                                        <i class="bi bi-car-front-fill"></i>
                                    </div>
                                    <h1 class="fw-bold">Antaksi'ye Hoş Geldiniz</h1>
                                    <p class="opacity-90">Profesyonel taksi deneyimine adım atın</p>
                                </div>
                                
                                <div class="mt-5">
                                    <h4><i class="bi bi-star-fill me-2"></i>Test Hesapları</h4>
                                    <div class="mt-3">
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="user-badge badge-passenger me-3">🧑 Yolcu</div>
                                            <div>
                                                <strong>emre@antaksi.com</strong><br>
                                                <small class="opacity-75">Şifre: emre123</small>
                                            </div>
                                        </div>
                                        
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="user-badge badge-driver me-3">🚕 Sürücü</div>
                                            <div>
                                                <strong>emre321@antaksi.com</strong><br>
                                                <small class="opacity-75">Şifre: emre321</small>
                                            </div>
                                        </div>
                                        
                                        <div class="d-flex align-items-center">
                                            <div class="user-badge badge-admin me-3">👑 Admin</div>
                                            <div>
                                                <strong>admin@antaksi.com</strong><br>
                                                <small class="opacity-75">Şifre: 123emre</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mt-5">
                                    <p class="opacity-90">
                                        <i class="bi bi-info-circle me-2"></i>
                                        Henüz hesabınız yok mu? 
                                        <a href="/register" class="text-white fw-bold">Hemen kayıt olun</a>
                                    </p>
                                </div>
                            </div>
                            
                            <!-- Right Side - Login Form -->
                            <div class="col-lg-6 p-5">
                                <h2 class="fw-bold mb-4">Hesabınıza Giriş Yapın</h2>
                                
                                <form method="POST">
                                    <div class="mb-4">
                                        <label class="form-label fw-bold">E-posta Adresi</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-light border-end-0">
                                                <i class="bi bi-envelope text-primary"></i>
                                            </span>
                                            <input type="email" name="email" class="form-control form-control-antaksi border-start-0" 
                                                   placeholder="ornek@email.com" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="form-label fw-bold">Şifre</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-light border-end-0">
                                                <i class="bi bi-lock text-primary"></i>
                                            </span>
                                            <input type="password" name="password" class="form-control form-control-antaksi border-start-0" 
                                                   placeholder="••••••••" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-4 form-check">
                                        <input type="checkbox" class="form-check-input" id="remember" name="remember">
                                        <label class="form-check-label" for="remember">Beni hatırla</label>
                                    </div>
                                    
                                    <button type="submit" class="antaksi-btn w-100 py-3 mb-4">
                                        <i class="bi bi-box-arrow-in-right me-2"></i>Giriş Yap
                                    </button>
                                    
                                    <div class="text-center">
                                        <p>
                                            Hesabınız yok mu? 
                                            <a href="/register" class="text-primary fw-bold text-decoration-none">
                                                Hemen kayıt olun
                                            </a>
                                        </p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    '''
    
    return render_template_string(get_base_html(login_content, "Giriş Yap", hide_nav=True, hide_footer=True))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect('/')
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        name = request.form.get('name')
        phone = request.form.get('phone')
        user_type = request.form.get('user_type', 'passenger')
        
        existing = User.query.filter_by(email=email).first()
        if existing:
            flash('Bu email zaten kayıtlı!', 'danger')
            return redirect('/register')
        
        user = User(email=email, name=name, phone=phone, user_type=user_type)
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash(f'Kayıt başarılı! Hoş geldiniz, {name}!', 'success')
        login_user(user)
        
        if user_type == 'passenger':
            return redirect('/passenger/dashboard')
        else:
            return redirect('/driver/dashboard')
    
    # Register sayfası içeriği
    register_content = '''
    <div class="login-container">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="login-card antaksi-card">
                        <div class="row g-0">
                            <div class="col-lg-6 p-5">
                                <h2 class="fw-bold mb-4">Antaksi Ailesine Katılın</h2>
                                <p class="text-muted mb-4">Profesyonel taksi deneyimini hemen başlatın.</p>
                                
                                <form method="POST">
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Ad Soyad</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-light border-end-0">
                                                <i class="bi bi-person text-primary"></i>
                                            </span>
                                            <input type="text" name="name" class="form-control form-control-antaksi border-start-0" 
                                                   placeholder="Adınız Soyadınız" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">E-posta Adresi</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-light border-end-0">
                                                <i class="bi bi-envelope text-primary"></i>
                                            </span>
                                            <input type="email" name="email" class="form-control form-control-antaksi border-start-0" 
                                                   placeholder="ornek@email.com" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Telefon Numarası</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-light border-end-0">
                                                <i class="bi bi-phone text-primary"></i>
                                            </span>
                                            <input type="tel" name="phone" class="form-control form-control-antaksi border-start-0" 
                                                   placeholder="05xx xxx xx xx" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="form-label fw-bold">Şifre</label>
                                        <div class="input-group">
                                            <span class="input-group-text bg-light border-end-0">
                                                <i class="bi bi-lock text-primary"></i>
                                            </span>
                                            <input type="password" name="password" class="form-control form-control-antaksi border-start-0" 
                                                   placeholder="••••••••" required minlength="6">
                                        </div>
                                        <div class="form-text">En az 6 karakter</div>
                                    </div>
                                    
                                    <div class="mb-4">
                                        <label class="form-label fw-bold">Hesap Türü</label>
                                        <div class="user-type-selector row g-3">
                                            <div class="col-md-6">
                                                <label class="w-100">
                                                    <input type="radio" name="user_type" value="passenger" class="d-none" checked>
                                                    <div class="card text-center p-4 h-100">
                                                        <div class="display-4 text-primary mb-2">
                                                            <i class="bi bi-person"></i>
                                                        </div>
                                                        <h5>Yolcu</h5>
                                                        <p class="text-muted small">Taksi çağırmak için</p>
                                                    </div>
                                                </label>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="w-100">
                                                    <input type="radio" name="user_type" value="driver" class="d-none">
                                                    <div class="card text-center p-4 h-100">
                                                        <div class="display-4 text-success mb-2">
                                                            <i class="bi bi-steering-wheel"></i>
                                                        </div>
                                                        <h5>Sürücü</h5>
                                                        <p class="text-muted small">Yolcu taşımak için</p>
                                                    </div>
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <button type="submit" class="antaksi-btn w-100 py-3 mb-4">
                                        <i class="bi bi-person-plus me-2"></i>Kayıt Ol
                                    </button>
                                    
                                    <div class="text-center">
                                        <p>
                                            Zaten hesabınız var mı? 
                                            <a href="/login" class="text-primary fw-bold text-decoration-none">
                                                Giriş yapın
                                            </a>
                                        </p>
                                    </div>
                                </form>
                            </div>
                            
                            <div class="col-lg-6 login-left">
                                <div class="text-center mb-5">
                                    <div class="display-1 mb-3">
                                        <i class="bi bi-car-front-fill"></i>
                                    </div>
                                    <h1 class="fw-bold">Neden Antaksi?</h1>
                                </div>
                                
                                <div class="mt-4">
                                    <div class="d-flex align-items-start mb-4">
                                        <div class="feature-icon me-3" style="width: 50px; height: 50px; font-size: 20px;">
                                            <i class="bi bi-lightning-charge"></i>
                                        </div>
                                        <div>
                                            <h5>Hızlı Başlangıç</h5>
                                            <p class="opacity-90 mb-0">60 saniyede kayıt ol, hemen taksi çağır.</p>
                                        </div>
                                    </div>
                                    
                                    <div class="d-flex align-items-start mb-4">
                                        <div class="feature-icon me-3" style="width: 50px; height: 50px; font-size: 20px;">
                                            <i class="bi bi-shield-check"></i>
                                        </div>
                                        <div>
                                            <h5>Güvenli Seyahat</h5>
                                            <p class="opacity-90 mb-0">Tüm sürücülerimiz titizlikle kontrol edilir.</p>
                                        </div>
                                    </div>
                                    
                                    <div class="d-flex align-items-start mb-4">
                                        <div class="feature-icon me-3" style="width: 50px; height: 50px; font-size: 20px;">
                                            <i class="bi bi-cash-coin"></i>
                                        </div>
                                        <div>
                                            <h5>Ekonomik Fiyatlar</h5>
                                            <p class="opacity-90 mb-0">Şeffaf fiyatlandırma, sürpriz yok.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    '''
    
    return render_template_string(get_base_html(register_content, "Kayıt Ol", hide_nav=True, hide_footer=True))

@app.route('/logout')
@login_required
def logout():
    name = current_user.name
    logout_user()
    flash(f'Güle güle, {name}! Tekrar bekleriz. 👋', 'info')
    return redirect('/')

# Dashboard sayfaları (kısaltılmış)
@app.route('/passenger/dashboard')
@login_required
def passenger_dashboard():
    if current_user.user_type != 'passenger':
        flash('Bu sayfaya erişim izniniz yok!', 'danger')
        return redirect('/')
    
    content = f'''
    <div class="container mt-5 pt-4">
        <div class="antaksi-card p-5">
            <h1 class="fw-bold mb-4">👋 Hoş geldiniz, {current_user.name}!</h1>
            <p class="lead">Yolcu paneline hoş geldiniz. Burada taksi çağırabilir, sürüşlerinizi takip edebilirsiniz.</p>
            
            <div class="row mt-5">
                <div class="col-md-4 mb-4">
                    <div class="antaksi-card p-4 text-center h-100">
                        <div class="display-4 text-primary mb-3">
                            <i class="bi bi-geo-alt"></i>
                        </div>
                        <h4>Taksi Çağır</h4>
                        <p class="text-muted">Hemen taksi çağırın</p>
                        <button class="antaksi-btn w-100">Şimdi Çağır</button>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="antaksi-card p-4 text-center h-100">
                        <div class="display-4 text-success mb-3">
                            <i class="bi bi-clock-history"></i>
                        </div>
                        <h4>Geçmiş Sürüşler</h4>
                        <p class="text-muted">Önceki yolculuklarınız</p>
                        <button class="antaksi-btn w-100">Görüntüle</button>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="antaksi-card p-4 text-center h-100">
                        <div class="display-4 text-warning mb-3">
                            <i class="bi bi-person-circle"></i>
                        </div>
                        <h4>Profilim</h4>
                        <p class="text-muted">Hesap ayarlarınız</p>
                        <button class="antaksi-btn w-100">Düzenle</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    '''
    
    return render_template_string(get_base_html(content, "Yolcu Paneli"))

@app.route('/driver/dashboard')
@login_required
def driver_dashboard():
    if current_user.user_type != 'driver':
        flash('Bu sayfaya erişim izniniz yok!', 'danger')
        return redirect('/')
    
    content = f'''
    <div class="container mt-5 pt-4">
        <div class="antaksi-card p-5">
            <h1 class="fw-bold mb-4">🚕 Hoş geldiniz, {current_user.name}!</h1>
            <p class="lead">Sürücü paneline hoş geldiniz. Yolcu bulun, kazanmaya başlayın.</p>
            
            <div class="row mt-5">
                <div class="col-md-4 mb-4">
                    <div class="antaksi-card p-4 text-center h-100">
                        <div class="display-4 text-primary mb-3">
                            <i class="bi bi-power"></i>
                        </div>
                        <h4>Çevrimiçi Ol</h4>
                        <p class="text-muted">Yolcu kabul etmeye başla</p>
                        <button class="antaksi-btn w-100" style="background: var(--secondary);">Başlat</button>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="antaksi-card p-4 text-center h-100">
                        <div class="display-4 text-success mb-3">
                            <i class="bi bi-list-check"></i>
                        </div>
                        <h4>Aktif Sürüşler</h4>
                        <p class="text-muted">Devam eden yolculuklar</p>
                        <button class="antaksi-btn w-100">Görüntüle</button>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="antaksi-card p-4 text-center h-100">
                        <div class="display-4 text-warning mb-3">
                            <i class="bi bi-cash-coin"></i>
                        </div>
                        <h4>Kazançlarım</h4>
                        <p class="text-muted">Toplam kazancınız</p>
                        <div class="display-6 fw-bold">₺0</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    '''
    
    return render_template_string(get_base_html(content, "Sürücü Paneli"))

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.user_type != 'admin':
        flash('Bu sayfaya erişim izniniz yok!', 'danger')
        return redirect('/')
    
    content = f'''
    <div class="container mt-5 pt-4">
        <div class="antaksi-card p-5">
            <h1 class="fw-bold mb-4">👑 Hoş geldiniz, {current_user.name}!</h1>
            <p class="lead">Admin paneline hoş geldiniz. Sistem yönetimi buradan yapılır.</p>
            
            <div class="mt-5">
                <h4>Yönetim Araçları</h4>
                <div class="d-flex flex-wrap gap-3 mt-3">
                    <button class="antaksi-btn">
                        <i class="bi bi-person-plus me-2"></i>Kullanıcı Ekle
                    </button>
                    <button class="antaksi-btn">
                        <i class="bi bi-gear me-2"></i>Sistem Ayarları
                    </button>
                    <button class="antaksi-btn">
                        <i class="bi bi-bar-chart me-2"></i>Raporlar
                    </button>
                </div>
            </div>
        </div>
    </div>
    '''
    
    return render_template_string(get_base_html(content, "Admin Paneli"))

# ========== FLASH MESSAGES YÖNETİMİ ==========
@app.before_request
def before_request():
    app.flash_messages = []

@app.after_request
def after_request(response):
    if hasattr(app, 'flash_messages'):
        delattr(app, 'flash_messages')
    return response

def flash(message, category='info'):
    if not hasattr(app, 'flash_messages'):
        app.flash_messages = []
    app.flash_messages.append((category, message))

# ========== BAŞLATMA ==========
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        print("✅ Database hazır!")
    
    print("="*70)
    print("🚖 ANTAKSİ - PROFESYONEL TAKSİ UYGULAMASI")
    print("="*70)
    print("🌐 Ana Sayfa: http://127.0.0.1:5000")
    print("🔑 Giriş: http://127.0.0.1:5000/login")
    print("📝 Kayıt: http://127.0.0.1:5000/register")
    print("\n📋 TEST HESAPLARI:")
    print("   🧑 Yolcu: emre@antaksi.com / emre123")
    print("   🚕 Sürücü: emre321@antaksi.com / emre321")
    print("   👑 Admin: admin@antaksi.com / 123emre")
    print("="*70)
    app.run(debug=True, host='0.0.0.0', port=5000, use_reloader=False)
