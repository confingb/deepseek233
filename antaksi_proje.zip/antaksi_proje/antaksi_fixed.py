﻿import os
from flask import Flask, render_template_string, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
import random

# ========== FLASK UYGULAMASI ==========
app = Flask(__name__)
app.config['SECRET_KEY'] = 'antaksi-pro-max-2024-emre'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///antaksi_pro.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Lütfen giriş yapınız!'

# ========== DATABASE MODELLERİ ==========
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    user_type = db.Column(db.String(20), nullable=False, default='passenger')
    profile_pic = db.Column(db.String(200), default='default.png')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Sürücü için ek alanlar
    vehicle_model = db.Column(db.String(50))
    vehicle_plate = db.Column(db.String(20))
    vehicle_color = db.Column(db.String(20))
    driver_rating = db.Column(db.Float, default=5.0)
    total_rides = db.Column(db.Integer, default=0)
    
    # Konum ve durum
    current_lat = db.Column(db.Float)
    current_lng = db.Column(db.Float)
    is_online = db.Column(db.Boolean, default=False)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_badge_color(self):
        if self.user_type == 'passenger':
            return 'success'
        elif self.user_type == 'driver':
            return 'warning'
        else:
            return 'danger'
    
    def get_icon(self):
        if self.user_type == 'passenger':
            return '👤'
        elif self.user_type == 'driver':
            return '🚕'
        else:
            return '👑'

class Ride(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    passenger_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    driver_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    pickup_address = db.Column(db.String(200))
    dropoff_address = db.Column(db.String(200))
    status = db.Column(db.String(20), default='requested')  # requested, accepted, in_progress, completed, cancelled
    fare = db.Column(db.Float)
    distance = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    completed_at = db.Column(db.DateTime)

@login_manager.user_loader
def load_user(id):
    return User.query.get(int(id))

# ========== HTML TEMPLATE FONKSİYONU ==========
def render_page(content, title="Antaksi", hide_nav=False, hide_footer=False, scripts="", styles=""):
    return f'''<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - 🚖 Antaksi</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <style>
        :root {{
            --primary: #0066FF;
            --primary-dark: #0052D4;
            --secondary: #00D4AA;
            --accent: #FF6B6B;
            --dark: #1A1A2E;
            --light: #F8F9FA;
            --gray: #6C757D;
            --gradient: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            --gradient-dark: linear-gradient(135deg, var(--primary-dark) 0%, #00B894 100%);
            --shadow: 0 10px 30px rgba(0, 102, 255, 0.15);
            --shadow-lg: 0 20px 60px rgba(0, 102, 255, 0.2);
        }}
        
        * {{
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            background: var(--light);
            color: var(--dark);
            min-height: 100vh;
            overflow-x: hidden;
        }}
        
        /* NAVBAR - GÜZELLEŞTİRİLMİŞ */
        .antaksi-navbar {{
            background: white !important;
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.08) !important;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
            padding: 12px 0;
            transition: all 0.3s ease;
        }}
        
        .antaksi-logo {{
            font-weight: 800;
            font-size: 28px;
            background: var(--gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 0 2px 10px rgba(0, 102, 255, 0.1);
        }}
        
        .nav-link {{
            color: var(--dark) !important;
            font-weight: 500;
            padding: 10px 20px !important;
            border-radius: 10px;
            margin: 0 5px;
            transition: all 0.3s ease;
        }}
        
        .nav-link:hover {{
            background: rgba(0, 102, 255, 0.08);
            transform: translateY(-2px);
            color: var(--primary) !important;
        }}
        
        .nav-link.active {{
            background: var(--gradient) !important;
            color: white !important;
            box-shadow: var(--shadow);
        }}
        
        /* BUTONLAR - ANİMASYONLU */
        .antaksi-btn {{
            background: var(--gradient);
            border: none;
            color: white;
            padding: 14px 32px;
            border-radius: 12px;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            box-shadow: var(--shadow);
        }}
        
        .antaksi-btn:hover {{
            transform: translateY(-3px);
            box-shadow: var(--shadow-lg);
            color: white;
        }}
        
        .antaksi-btn:active {{
            transform: translateY(-1px);
        }}
        
        .antaksi-btn::after {{
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 5px;
            height: 5px;
            background: rgba(255, 255, 255, 0.5);
            opacity: 0;
            border-radius: 100%;
            transform: scale(1, 1) translate(-50%);
            transform-origin: 50% 50%;
        }}
        
        .antaksi-btn:focus:not(:active)::after {{
            animation: ripple 1s ease-out;
        }}
        
        @keyframes ripple {{
            0% {{
                transform: scale(0, 0);
                opacity: 0.5;
            }}
            100% {{
                transform: scale(50, 50);
                opacity: 0;
            }}
        }}
        
        .antaksi-btn-success {{
            background: linear-gradient(135deg, #00D4AA 0%, #00B894 100%);
        }}
        
        .antaksi-btn-warning {{
            background: linear-gradient(135deg, #FFD166 0%, #FFB347 100%);
        }}
        
        .antaksi-btn-danger {{
            background: linear-gradient(135deg, #FF6B6B 0%, #EE5A52 100%);
        }}
        
        /* KARTLAR */
        .antaksi-card {{
            background: white;
            border-radius: 20px;
            border: none;
            box-shadow: var(--shadow);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
        }}
        
        .antaksi-card:hover {{
            transform: translateY(-10px);
            box-shadow: var(--shadow-lg);
        }}
        
        .card-header {{
            background: var(--gradient);
            color: white;
            font-weight: 600;
            border: none;
            padding: 20px 30px;
        }}
        
        /* FORM ELEMENTLERİ */
        .form-control-antaksi {{
            border: 2px solid #E8F0FE;
            border-radius: 12px;
            padding: 16px 20px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: #F8FAFF;
        }}
        
        .form-control-antaksi:focus {{
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(0, 102, 255, 0.1);
            background: white;
            transform: translateY(-2px);
        }}
        
        /* USER BADGES */
        .user-badge {{
            display: inline-flex;
            align-items: center;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 14px;
            gap: 8px;
        }}
        
        .badge-passenger {{
            background: linear-gradient(135deg, #E3F2FD 0%, #BBDEFB 100%);
            color: #1565C0;
        }}
        
        .badge-driver {{
            background: linear-gradient(135deg, #FFF3E0 0%, #FFE0B2 100%);
            color: #EF6C00;
        }}
        
        .badge-admin {{
            background: linear-gradient(135deg, #FFEBEE 0%, #FFCDD2 100%);
            color: #C62828;
        }}
        
        /* DASHBOARD STYLES */
        .dashboard-card {{
            height: 100%;
            border-left: 5px solid var(--primary);
        }}
        
        .stat-card {{
            background: white;
            border-radius: 15px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s ease;
        }}
        
        .stat-card:hover {{
            transform: translateY(-5px);
        }}
        
        .stat-icon {{
            width: 70px;
            height: 70px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            margin: 0 auto 20px;
            background: var(--gradient);
            color: white;
        }}
        
        /* ANIMATIONS */
        .pulse {{
            animation: pulse 2s infinite;
        }}
        
        @keyframes pulse {{
            0% {{ transform: scale(1); }}
            50% {{ transform: scale(1.05); }}
            100% {{ transform: scale(1); }}
        }}
        
        .float {{
            animation: float 3s ease-in-out infinite;
        }}
        
        @keyframes float {{
            0% {{ transform: translateY(0px); }}
            50% {{ transform: translateY(-10px); }}
            100% {{ transform: translateY(0px); }}
        }}
        
        /* RESPONSIVE */
        @media (max-width: 768px) {{
            .antaksi-logo {{
                font-size: 24px;
            }}
            
            .antaksi-btn {{
                padding: 12px 24px;
                font-size: 14px;
            }}
            
            .nav-link {{
                padding: 8px 16px !important;
                margin: 2px 0;
            }}
        }}
        
        /* TOGGLE SWITCH */
        .switch {{
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }}
        
        .switch input {{
            opacity: 0;
            width: 0;
            height: 0;
        }}
        
        .slider {{
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }}
        
        .slider:before {{
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }}
        
        input:checked + .slider {{
            background: var(--gradient);
        }}
        
        input:checked + .slider:before {{
            transform: translateX(26px);
        }}
    </style>
    
    {styles}
</head>
<body>
    <!-- Navigation -->
    {'' if hide_nav else f'''
    <nav class="navbar navbar-expand-lg navbar-light antaksi-navbar fixed-top">
        <div class="container">
            <a class="navbar-brand antaksi-logo animate__animated animate__fadeIn" href="/">
                <i class="bi bi-car-front-fill me-2"></i>Antaksi
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    {' '.join([
                        # Giriş yapmış kullanıcı için
                        f'''<li class="nav-item">
                            <a class="nav-link {'active' if request.path == '/passenger/dashboard' else ''}" href="/passenger/dashboard">
                                <i class="bi bi-speedometer2 me-1"></i>Panel
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/profile">
                                <i class="bi bi-person-circle me-1"></i>Profil
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                                <span class="user-badge badge-{current_user.user_type} me-2">
                                    {current_user.get_icon()} {current_user.name.split()[0]}
                                </span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><h6 class="dropdown-header">{current_user.name}</h6></li>
                                <li><a class="dropdown-item" href="/profile"><i class="bi bi-person"></i> Profilim</a></li>
                                <li><a class="dropdown-item" href="/settings"><i class="bi bi-gear"></i> Ayarlar</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item text-danger" href="/logout"><i class="bi bi-box-arrow-right"></i> Çıkış Yap</a></li>
                            </ul>
                        </li>''' if current_user.is_authenticated else
                        # Giriş yapmamış kullanıcı için
                        f'''<li class="nav-item">
                            <a class="nav-link {'active' if request.path == '/' else ''}" href="/">
                                <i class="bi bi-house me-1"></i>Ana Sayfa
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {'active' if request.path == '/login' else ''}" href="/login">
                                <i class="bi bi-box-arrow-in-right me-1"></i>Giriş Yap
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link antaksi-btn px-4 text-white {'active' if request.path == '/register' else ''}" 
                               href="/register" style="padding: 8px 20px !important;">
                                <i class="bi bi-person-plus me-1"></i>Kayıt Ol
                            </a>
                        </li>'''
                    ])}
                </ul>
            </div>
        </div>
    </nav>'''}
    
    <!-- Main Content -->
    <main class="{'' if hide_nav else 'pt-5 mt-4'} animate__animated animate__fadeIn">
        {content}
    </main>
    
    <!-- Footer -->
    {'' if hide_footer else '''
    <footer class="bg-dark text-white py-5 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <h3 class="antaksi-logo mb-3">Antaksi</h3>
                    <p class="text-light">Profesyonel, güvenli ve hızlı taksi hizmeti.</p>
                </div>
                <div class="col-lg-8 text-lg-end">
                    <p class="text-white-50 mb-0">&copy; 2024 Antaksi. Tüm hakları saklıdır.</p>
                </div>
            </div>
        </div>
    </footer>'''}
    
    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Button animation
        document.querySelectorAll('.antaksi-btn').forEach(btn => {{
            btn.addEventListener('click', function(e) {{
                // Bounce animation
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {{
                    this.style.transform = 'scale(1)';
                }}, 150);
            }});
        }});
        
        // Toggle switch animation
        document.querySelectorAll('.switch input').forEach(toggle => {{
            toggle.addEventListener('change', function() {{
                const slider = this.nextElementSibling;
                const isChecked = this.checked;
                
                if (isChecked) {{
                    slider.style.transform = 'translateX(26px)';
                    alert('Çevrimiçi durumundasınız!');
                }} else {{
                    slider.style.transform = 'translateX(0)';
                    alert('Çevrimdışı durumundasınız!');
                }}
            }});
        }});
        
        // Auto-hide alerts
        setTimeout(() => {{
            document.querySelectorAll('.alert').forEach(alert => {{
                alert.style.opacity = '0';
                alert.style.transition = 'opacity 0.5s';
                setTimeout(() => alert.remove(), 500);
            }});
        }}, 5000);
        
        // Page load animation
        document.addEventListener('DOMContentLoaded', () => {{
            document.querySelector('main').style.opacity = '1';
            document.querySelector('main').style.transform = 'translateY(0)';
        }});
    </script>
    
    {scripts}
</body>
</html>'''

# ========== ROUTE'LAR ==========

@app.route('/')
def home():
    if current_user.is_authenticated:
        return redirect(f'/{current_user.user_type}/dashboard')
    
    content = '''
    <!-- Hero Section -->
    <section class="hero-section" style="background: var(--gradient); color: white; padding: 120px 0 80px; border-radius: 0 0 40px 40px;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4 animate__animated animate__fadeInUp">Profesyonel Taksi Deneyimi</h1>
                    <p class="lead mb-4 opacity-90 animate__animated animate__fadeInUp animate__delay-1s">
                        Antaksi ile güvenli, hızlı ve konforlu seyahat edin. Anında taksi bulun, güvenle yolculuk yapın.
                    </p>
                    <div class="d-flex flex-wrap gap-3 animate__animated animate__fadeInUp animate__delay-2s">
                        <a href="/register" class="antaksi-btn pulse">
                            <i class="bi bi-lightning-charge me-2"></i>Hemen Başlayın
                        </a>
                        <a href="/login" class="antaksi-btn antaksi-btn-outline" style="background: rgba(255,255,255,0.1); border-color: white;">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Giriş Yap
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <div class="float animate__animated animate__fadeIn">
                        <div style="font-size: 150px;">🚖</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Features -->
    <section class="container py-5">
        <div class="text-center mb-5">
            <h2 class="fw-bold">Neden Antaksi?</h2>
            <p class="text-muted">Profesyonel taksi deneyiminin en iyisi</p>
        </div>
        
        <div class="row g-4">
            <div class="col-md-4">
                <div class="antaksi-card p-4 text-center h-100">
                    <div class="stat-icon">
                        <i class="bi bi-lightning-charge"></i>
                    </div>
                    <h4 class="mt-3">Hızlı</h4>
                    <p class="text-muted">Ortalama 3 dakikada taksi.</p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="antaksi-card p-4 text-center h-100">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #00D4AA 0%, #00B894 100%);">
                        <i class="bi bi-shield-check"></i>
                    </div>
                    <h4 class="mt-3">Güvenli</h4>
                    <p class="text-muted">Tüm sürücüler kontrol edilmiştir.</p>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="antaksi-card p-4 text-center h-100">
                    <div class="stat-icon" style="background: linear-gradient(135deg, #FFD166 0%, #FFB347 100%);">
                        <i class="bi bi-cash-coin"></i>
                    </div>
                    <h4 class="mt-3">Uygun Fiyat</h4>
                    <p class="text-muted">Sabit fiyat garantisi.</p>
                </div>
            </div>
        </div>
    </section>
    '''
    
    return render_template_string(render_page(content, "Ana Sayfa"))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        flash('Zaten giriş yaptınız!', 'info')
        return redirect(f'/{current_user.user_type}/dashboard')
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            if user.is_active:
                login_user(user, remember=True)
                flash(f'Hoş geldiniz, {user.name}! 🎉', 'success')
                return redirect(f'/{user.user_type}/dashboard')
            else:
                flash('Hesabınız aktif değil!', 'danger')
        else:
            flash('Email veya şifre hatalı!', 'danger')
    
    content = '''
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="antaksi-card p-5">
                    <div class="text-center mb-5">
                        <div class="stat-icon mb-3">
                            <i class="bi bi-box-arrow-in-right"></i>
                        </div>
                        <h2 class="fw-bold">Giriş Yap</h2>
                        <p class="text-muted">Hesabınıza erişin</p>
                    </div>
                    
                    <form method="POST">
                        <div class="mb-4">
                            <label class="form-label fw-bold">E-posta</label>
                            <input type="email" name="email" class="form-control form-control-antaksi" 
                                   placeholder="ornek@email.com" required>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">Şifre</label>
                            <input type="password" name="password" class="form-control form-control-antaksi" 
                                   placeholder="••••••••" required>
                        </div>
                        
                        <button type="submit" class="antaksi-btn w-100 py-3 mb-3">
                            <i class="bi bi-box-arrow-in-right me-2"></i>Giriş Yap
                        </button>
                        
                        <div class="text-center">
                            <p class="mb-0">
                                Hesabınız yok mu? 
                                <a href="/register" class="text-primary fw-bold text-decoration-none">
                                    Kayıt Olun
                                </a>
                            </p>
                        </div>
                    </form>
                    
                    <hr class="my-4">
                    
                    <div class="text-center">
                        <h6 class="mb-3">Test Hesapları</h6>
                        <div class="row g-2">
                            <div class="col-12">
                                <div class="alert alert-info p-2">
                                    <small><strong>🧑 Yolcu:</strong> emre@antaksi.com / emre123</small>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="alert alert-warning p-2">
                                    <small><strong>🚕 Sürücü:</strong> emre321@antaksi.com / emre321</small>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="alert alert-danger p-2">
                                    <small><strong>👑 Admin:</strong> admin@antaksi.com / 123emre</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    '''
    
    return render_template_string(render_page(content, "Giriş Yap"))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(f'/{current_user.user_type}/dashboard')
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        name = request.form.get('name')
        phone = request.form.get('phone')
        user_type = request.form.get('user_type', 'passenger')
        
        existing = User.query.filter_by(email=email).first()
        if existing:
            flash('Bu email zaten kayıtlı!', 'danger')
            return redirect('/register')
        
        user = User(email=email, name=name, phone=phone, user_type=user_type)
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash(f'Kayıt başarılı! Hoş geldiniz, {name}!', 'success')
        login_user(user)
        return redirect(f'/{user_type}/dashboard')
    
    content = '''
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="antaksi-card p-5">
                    <div class="text-center mb-5">
                        <div class="stat-icon mb-3">
                            <i class="bi bi-person-plus"></i>
                        </div>
                        <h2 class="fw-bold">Kayıt Ol</h2>
                        <p class="text-muted">Antaksi ailesine katılın</p>
                    </div>
                    
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Ad Soyad</label>
                                <input type="text" name="name" class="form-control form-control-antaksi" 
                                       placeholder="Adınız Soyadınız" required>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Telefon</label>
                                <input type="tel" name="phone" class="form-control form-control-antaksi" 
                                       placeholder="05xx xxx xx xx" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">E-posta</label>
                            <input type="email" name="email" class="form-control form-control-antaksi" 
                                   placeholder="ornek@email.com" required>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">Şifre</label>
                            <input type="password" name="password" class="form-control form-control-antaksi" 
                                   placeholder="••••••••" required minlength="6">
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-bold">Hesap Türü</label>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="d-block">
                                        <input type="radio" name="user_type" value="passenger" class="d-none" checked>
                                        <div class="antaksi-card p-4 text-center cursor-pointer user-type-card">
                                            <div class="display-4 text-primary mb-2">
                                                <i class="bi bi-person"></i>
                                            </div>
                                            <h5>Yolcu</h5>
                                            <p class="text-muted small">Taksi çağırmak için</p>
                                        </div>
                                    </label>
                                </div>
                                <div class="col-md-6">
                                    <label class="d-block">
                                        <input type="radio" name="user_type" value="driver" class="d-none">
                                        <div class="antaksi-card p-4 text-center cursor-pointer user-type-card">
                                            <div class="display-4 text-warning mb-2">
                                                <i class="bi bi-steering-wheel"></i>
                                            </div>
                                            <h5>Sürücü</h5>
                                            <p class="text-muted small">Yolcu taşımak için</p>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>
                        
                        <button type="submit" class="antaksi-btn w-100 py-3 mb-3">
                            <i class="bi bi-person-plus me-2"></i>Kayıt Ol
                        </button>
                        
                        <div class="text-center">
                            <p class="mb-0">
                                Zaten hesabınız var mı? 
                                <a href="/login" class="text-primary fw-bold text-decoration-none">
                                    Giriş Yapın
                                </a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // User type selection animation
        document.querySelectorAll('.user-type-card').forEach(card => {
            card.addEventListener('click', function() {
                document.querySelectorAll('.user-type-card').forEach(c => {
                    c.style.transform = 'scale(1)';
                    c.style.boxShadow = 'var(--shadow)';
                });
                
                this.style.transform = 'scale(1.05)';
                this.style.boxShadow = 'var(--shadow-lg)';
                
                this.querySelector('input[type="radio"]').checked = true;
            });
        });
    </script>
    '''
    
    return render_template_string(render_page(content, "Kayıt Ol"))

@app.route('/logout')
@login_required
def logout():
    name = current_user.name
    logout_user()
    flash(f'Güle güle, {name}! Tekrar bekleriz. 👋', 'info')
    return redirect('/')

# ========== DASHBOARD SAYFALARI ==========

@app.route('/passenger/dashboard')
@login_required
def passenger_dashboard():
    if current_user.user_type != 'passenger':
        flash('Bu sayfaya erişim izniniz yok!', 'danger')
        return redirect('/')
    
    content = f'''
    <div class="container py-4">
        <!-- Welcome Card -->
        <div class="antaksi-card p-4 mb-4 dashboard-card">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="fw-bold mb-2">Hoş Geldiniz, {current_user.name}! 👋</h1>
                    <p class="text-muted mb-0">Antaksi yolcu panelinize hoş geldiniz.</p>
                </div>
                <div class="col-md-4 text-end">
                    <span class="user-badge badge-passenger">
                        <i class="bi bi-person"></i> Yolcu
                    </span>
                </div>
            </div>
        </div>
        
        <!-- Action Cards -->
        <div class="row g-4">
            <div class="col-md-6">
                <div class="antaksi-card p-4 h-100">
                    <h4 class="fw-bold mb-3"><i class="bi bi-geo-alt me-2"></i>Taksi Çağır</h4>
                    <p class="text-muted mb-4">Hemen bir taksi çağırın.</p>
                    <button class="antaksi-btn w-100 py-3" onclick="callTaxi()">
                        <i class="bi bi-telephone me-2"></i>Taksi Çağır
                    </button>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="antaksi-card p-4 h-100">
                    <h4 class="fw-bold mb-3"><i class="bi bi-clock-history me-2"></i>Geçmiş Sürüşler</h4>
                    <p class="text-muted mb-4">Önceki yolculuklarınızı görüntüleyin.</p>
                    <button class="antaksi-btn antaksi-btn-success w-100 py-3" onclick="viewRides()">
                        <i class="bi bi-list-check me-2"></i>Sürüşleri Gör
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="row g-3 mt-4">
            <div class="col-6 col-md-3">
                <button class="antaksi-card p-3 w-100 border-0 text-center" onclick="openProfile()">
                    <div class="display-4 mb-2 text-primary">
                        <i class="bi bi-person-circle"></i>
                    </div>
                    <h6>Profil</h6>
                </button>
            </div>
            <div class="col-6 col-md-3">
                <button class="antaksi-card p-3 w-100 border-0 text-center" onclick="openSettings()">
                    <div class="display-4 mb-2 text-primary">
                        <i class="bi bi-gear"></i>
                    </div>
                    <h6>Ayarlar</h6>
                </button>
            </div>
            <div class="col-6 col-md-3">
                <button class="antaksi-card p-3 w-100 border-0 text-center" onclick="openHelp()">
                    <div class="display-4 mb-2 text-primary">
                        <i class="bi bi-question-circle"></i>
                    </div>
                    <h6>Yardım</h6>
                </button>
            </div>
            <div class="col-6 col-md-3">
                <button class="antaksi-card p-3 w-100 border-0 text-center" onclick="openWallet()">
                    <div class="display-4 mb-2 text-primary">
                        <i class="bi bi-wallet2"></i>
                    </div>
                    <h6>Cüzdan</h6>
                </button>
            </div>
        </div>
    </div>
    
    <script>
        function callTaxi() {{
            const btn = event.target.closest('button');
            btn.style.transform = 'scale(0.95)';
            
            setTimeout(() => {{
                btn.style.transform = 'scale(1)';
                alert('🚖 Taksi çağrınız alındı! En yakın sürücü yola çıktı.');
                btn.innerHTML = '<i class="bi bi-check-circle me-2"></i>Taksi Yolda!';
                btn.classList.remove('antaksi-btn');
                btn.classList.add('antaksi-btn-success');
                btn.disabled = true;
            }}, 150);
        }}
        
        function viewRides() {{
            alert('📋 Geçmiş sürüşleriniz görüntülenecek...');
        }}
        
        function openProfile() {{
            window.location.href = '/profile';
        }}
        
        function openSettings() {{
            window.location.href = '/settings';
        }}
        
        function openHelp() {{
            alert('📞 Yardım merkezi açılıyor...');
        }}
        
        function openWallet() {{
            alert('💰 Cüzdanınız açılıyor...');
        }}
    </script>
    '''
    
    return render_template_string(render_page(content, "Yolcu Paneli"))

@app.route('/driver/dashboard')
@login_required
def driver_dashboard():
    if current_user.user_type != 'driver':
        flash('Bu sayfaya erişim izniniz yok!', 'danger')
        return redirect('/')
    
    content = f'''
    <div class="container py-4">
        <!-- Welcome Card -->
        <div class="antaksi-card p-4 mb-4 dashboard-card" style="border-left-color: #FFC107;">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="fw-bold mb-2">Hoş Geldiniz, {current_user.name}! 🚕</h1>
                    <p class="text-muted mb-0">Antaksi sürücü panelinize hoş geldiniz.</p>
                </div>
                <div class="col-md-4 text-end">
                    <span class="user-badge badge-driver">
                        <i class="bi bi-steering-wheel"></i> Sürücü
                    </span>
                </div>
            </div>
        </div>
        
        <!-- Online Toggle -->
        <div class="antaksi-card p-4 mb-4">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h4 class="fw-bold mb-1">Çevrimiçi Durumu</h4>
                    <p class="text-muted mb-0">Yolcu kabul etmek için çevrimiçi olun</p>
                </div>
                <div class="col-md-4 text-end">
                    <label class="switch">
                        <input type="checkbox" id="onlineToggle" {'checked' if current_user.is_online else ''}>
                        <span class="slider"></span>
                    </label>
                </div>
            </div>
        </div>
        
        <!-- Action Cards -->
        <div class="row g-4">
            <div class="col-md-6">
                <div class="antaksi-card p-4 h-100">
                    <h4 class="fw-bold mb-3"><i class="bi bi-list-check me-2"></i>Aktif Sürüşler</h4>
                    <p class="text-muted mb-4">Devam eden yolculuklarınızı yönetin.</p>
                    <button class="antaksi-btn w-100 py-3" onclick="viewActiveRides()">
                        <i class="bi bi-eye me-2"></i>Sürüşleri Gör
                    </button>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="antaksi-card p-4 h-100">
                    <h4 class="fw-bold mb-3"><i class="bi bi-bar-chart me-2"></i>Performans</h4>
                    <p class="text-muted mb-4">Sürüş performansınızı analiz edin.</p>
                    <button class="antaksi-btn antaksi-btn-success w-100 py-3" onclick="viewPerformance()">
                        <i class="bi bi-graph-up me-2"></i>Performansı Gör
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Online toggle
        document.getElementById('onlineToggle').addEventListener('change', function() {{
            const status = this.checked ? 'çevrimiçi' : 'çevrimdışı';
            alert('Şu anda ' + status + ' durumundasınız!');
        }});
        
        function viewActiveRides() {{
            alert('🚗 Aktif sürüşleriniz görüntülenecek...');
        }}
        
        function viewPerformance() {{
            alert('📊 Performans raporunuz açılıyor...');
        }}
    </script>
    '''
    
    return render_template_string(render_page(content, "Sürücü Paneli"))

@app.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.user_type != 'admin':
        flash('Bu sayfaya erişim izniniz yok!', 'danger')
        return redirect('/')
    
    content = f'''
    <div class="container py-4">
        <!-- Welcome Card -->
        <div class="antaksi-card p-4 mb-4 dashboard-card" style="border-left-color: #DC3545;">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h1 class="fw-bold mb-2">Hoş Geldiniz, {current_user.name}! 👑</h1>
                    <p class="text-muted mb-0">Antaksi admin panelinize hoş geldiniz.</p>
                </div>
                <div class="col-md-4 text-end">
                    <span class="user-badge badge-admin">
                        <i class="bi bi-shield-check"></i> Admin
                    </span>
                </div>
            </div>
        </div>
        
        <!-- Admin Actions -->
        <div class="row g-4">
            <div class="col-md-6">
                <div class="antaksi-card p-4 h-100">
                    <h4 class="fw-bold mb-3"><i class="bi bi-person-plus me-2"></i>Kullanıcı Yönetimi</h4>
                    <p class="text-muted mb-4">Kullanıcıları yönetin.</p>
                    <button class="antaksi-btn w-100 py-3 mb-2" onclick="manageUsers()">
                        <i class="bi bi-people me-2"></i>Kullanıcıları Yönet
                    </button>
                    <button class="antaksi-btn antaksi-btn-success w-100 py-3" onclick="addUser()">
                        <i class="bi bi-person-add me-2"></i>Yeni Kullanıcı Ekle
                    </button>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="antaksi-card p-4 h-100">
                    <h4 class="fw-bold mb-3"><i class="bi bi-gear me-2"></i>Sistem Ayarları</h4>
                    <p class="text-muted mb-4">Sistem ayarlarını yapılandırın.</p>
                    <button class="antaksi-btn w-100 py-3 mb-2" onclick="systemSettings()">
                        <i class="bi bi-sliders me-2"></i>Ayarları Yapılandır
                    </button>
                    <button class="antaksi-btn antaksi-btn-warning w-100 py-3" onclick="viewLogs()">
                        <i class="bi bi-journal-text me-2"></i>Sistem Logları
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function manageUsers() {{
            alert('👥 Kullanıcı yönetim paneli açılıyor...');
        }}
        
        function addUser() {{
            alert('➕ Yeni kullanıcı ekleme formu açılıyor...');
        }}
        
        function systemSettings() {{
            alert('⚙️ Sistem ayarları paneli açılıyor...');
        }}
        
        function viewLogs() {{
            alert('📋 Sistem logları görüntülenecek...');
        }}
    </script>
    '''
    
    return render_template_string(render_page(content, "Admin Paneli"))

# ========== PROFILE & SETTINGS ==========

@app.route('/profile')
@login_required
def profile():
    content = f'''
    <div class="container py-4">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="antaksi-card p-4 text-center">
                    <div class="mb-3">
                        <div style="width: 120px; height: 120px; border-radius: 50%; background: var(--gradient); 
                             display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 48px; color: white;">
                            {current_user.get_icon()}
                        </div>
                        <h3 class="fw-bold">{current_user.name}</h3>
                        <span class="user-badge badge-{current_user.user_type}">
                            {current_user.get_icon()} {current_user.user_type.capitalize()}
                        </span>
                    </div>
                    
                    <div class="mt-4">
                        <button class="antaksi-btn w-100 mb-2" onclick="editProfile()">
                            <i class="bi bi-pencil me-2"></i>Profili Düzenle
                        </button>
                        <button class="antaksi-btn antaksi-btn-outline w-100" onclick="changePassword()">
                            <i class="bi bi-key me-2"></i>Şifre Değiştir
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-8">
                <div class="antaksi-card p-4">
                    <h4 class="fw-bold mb-4">Profil Bilgileri</h4>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Ad Soyad</label>
                            <div class="form-control-antaksi">{current_user.name}</div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">E-posta</label>
                            <div class="form-control-antaksi">{current_user.email}</div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Telefon</label>
                            <div class="form-control-antaksi">{current_user.phone}</div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label class="form-label text-muted">Üyelik Tarihi</label>
                            <div class="form-control-antaksi">{current_user.created_at.strftime('%d.%m.%Y')}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function editProfile() {{
            alert('✏️ Profil düzenleme formu açılıyor...');
        }}
        
        function changePassword() {{
            alert('🔐 Şifre değiştirme formu açılıyor...');
        }}
    </script>
    '''
    
    return render_template_string(render_page(content, "Profilim"))

@app.route('/settings')
@login_required
def settings():
    content = '''
    <div class="container py-4">
        <div class="antaksi-card p-4">
            <h4 class="fw-bold mb-4">Ayarlar</h4>
            
            <div class="mb-4">
                <h5 class="fw-bold mb-3"><i class="bi bi-bell me-2"></i>Bildirim Ayarları</h5>
                <div class="form-check form-switch mb-2">
                    <input class="form-check-input" type="checkbox" id="notifRide" checked>
                    <label class="form-check-label" for="notifRide">Sürüş bildirimleri</label>
                </div>
                <div class="form-check form-switch mb-2">
                    <input class="form-check-input" type="checkbox" id="notifPromo" checked>
                    <label class="form-check-label" for="notifPromo">Promosyon bildirimleri</label>
                </div>
            </div>
            
            <hr class="my-4">
            
            <div class="mb-4">
                <h5 class="fw-bold mb-3"><i class="bi bi-palette me-2"></i>Tema</h5>
                <div class="row g-2">
                    <div class="col-4">
                        <button class="antaksi-card p-3 w-100 border-0 text-center" onclick="setTheme('light')">
                            <div class="display-4 mb-2">
                                <i class="bi bi-sun"></i>
                            </div>
                            <h6>Açık</h6>
                        </button>
                    </div>
                    <div class="col-4">
                        <button class="antaksi-card p-3 w-100 border-0 text-center" onclick="setTheme('dark')">
                            <div class="display-4 mb-2">
                                <i class="bi bi-moon"></i>
                            </div>
                            <h6>Koyu</h6>
                        </button>
                    </div>
                    <div class="col-4">
                        <button class="antaksi-card p-3 w-100 border-0 text-center" onclick="setTheme('auto')">
                            <div class="display-4 mb-2">
                                <i class="bi bi-circle-half"></i>
                            </div>
                            <h6>Otomatik</h6>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function setTheme(theme) {{
            alert('🎨 Tema "' + theme + '" olarak ayarlandı!');
            document.documentElement.setAttribute('data-bs-theme', theme);
        }}
    </script>
    '''
    
    return render_template_string(render_page(content, "Ayarlar"))

# ========== BAŞLATMA ==========
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        
        # Test kullanıcılarını oluştur
        test_users = [
            ('emre@antaksi.com', 'emre123', 'Emre Yolcu', '05551112233', 'passenger'),
            ('emre321@antaksi.com', 'emre321', 'Emre Sürücü', '05554445566', 'driver'),
            ('admin@antaksi.com', '123emre', 'Admin Emre', '05557778899', 'admin'),
        ]
        
        for email, password, name, phone, user_type in test_users:
            if not User.query.filter_by(email=email).first():
                user = User(email=email, name=name, phone=phone, user_type=user_type)
                user.set_password(password)
                db.session.add(user)
        
        db.session.commit()
        print("✅ Database ve test kullanıcıları hazır!")
    
    print("="*80)
    print("🚖 ANTAKSİ PRO MAX - PROFESYONEL TAKSİ UYGULAMASI")
    print("="*80)
    print("🌐 Ana Sayfa: http://127.0.0.1:5000")
    print("🔑 Giriş: http://127.0.0.1:5000/login")
    print("📝 Kayıt: http://127.0.0.1:5000/register")
    print("\n📋 TEST HESAPLARI:")
    print("   🧑 Yolcu: emre@antaksi.com / emre123")
    print("   🚕 Sürücü: emre321@antaksi.com / emre321")
    print("   👑 Admin: admin@antaksi.com / 123emre")
    print("="*80)
    
    app.run(debug=True, host='0.0.0.0', port=5000, use_reloader=False)
