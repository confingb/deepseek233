﻿import os
from datetime import timedelta
from dotenv import load_dotenv

basedir = os.path.abspath(os.path.dirname(__file__))
load_dotenv()

# instance klasörünü oluştur (eğer yoksa)
instance_dir = os.path.join(basedir, 'instance')
if not os.path.exists(instance_dir):
    os.makedirs(instance_dir)

class Config:
    # Temel ayarlar
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'antaksi-pro-secret-key-2024'
    
    # Database - DÜZGÜN PATH
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(instance_dir, 'antaksi.db')
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Security
    SECURITY_PASSWORD_SALT = os.environ.get('SECURITY_PASSWORD_SALT') or 'another-secret-salt'
    REMEMBER_COOKIE_DURATION = timedelta(days=7)
    
    # Mobile/Web
    PWA_NAME = 'Antaksi'
    PWA_DESCRIPTION = 'Profesyonel Taksi Hizmeti'
    PWA_THEME_COLOR = '#0d6efd'
    PWA_BACKGROUND_COLOR = '#ffffff'
    
class DevelopmentConfig(Config):
    DEBUG = True
    SQLALCHEMY_ECHO = True

class ProductionConfig(Config):
    DEBUG = False
    
class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'

config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}
