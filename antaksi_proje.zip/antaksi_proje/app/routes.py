from flask import Blueprint, render_template, jsonify, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app import db
from app.models import User, Driver, Trip
from datetime import datetime
import random
import json

# Blueprint'leri oluştur
main = Blueprint('main', __name__)
api = Blueprint('api', __name__)

# ========== ANA SAYFALAR ==========
@main.route('/')
def index():
    return render_template('index.html')

@main.route('/booking')
@login_required
def booking():
    return render_template('booking.html')

@main.route('/dashboard')
@login_required
def dashboard():
    if current_user.user_type == 'admin':
        return redirect(url_for('admin.dashboard'))
    elif current_user.user_type == 'driver':
        return redirect(url_for('driver.dashboard'))
    else:
        # Yolcu dashboard'u
        trips = Trip.query.filter_by(passenger_id=current_user.id).order_by(Trip.created_at.desc()).limit(10).all()
        return render_template('dashboard.html', trips=trips)

# ========== AUTH ROUTE'ları (Giriş/Kayıt) ==========
@main.route('/login')
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    return render_template('auth/login.html')

@main.route('/register')
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    return render_template('auth/register.html')

@main.route('/forgot-password')
def forgot_password():
    return render_template('auth/reset_password.html')

# ========== ADMIN PANELI ==========
@main.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.user_type != 'admin':
        flash('Bu sayfaya erişim izniniz yok', 'error')
        return redirect(url_for('main.index'))
    
    # Admin istatistikleri
    total_users = User.query.count()
    total_drivers = Driver.query.count()
    total_trips = Trip.query.count()
    
    return render_template('admin/dashboard.html',
                         total_users=total_users,
                         total_drivers=total_drivers,
                         total_trips=total_trips)

@main.route('/admin/users')
@login_required
def admin_users():
    if current_user.user_type != 'admin':
        return redirect(url_for('main.index'))
    
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin/users.html', users=users)

# ========== SÜRÜCÜ PANELI ==========
@main.route('/driver/dashboard')
@login_required
def driver_dashboard():
    if current_user.user_type != 'driver':
        flash('Bu sayfaya erişim izniniz yok', 'error')
        return redirect(url_for('main.index'))
    
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        flash('Sürücü profiliniz bulunamadı', 'error')
        return redirect(url_for('main.index'))
    
    # Aktif yolculuklar
    active_trips = Trip.query.filter_by(
        driver_id=driver.id,
        status__in=['accepted', 'arrived', 'ongoing']
    ).order_by(Trip.created_at.desc()).all()
    
    return render_template('driver/dashboard.html',
                         driver=driver,
                         active_trips=active_trips)

# ========== API ROUTES ==========
@api.route('/estimate', methods=['POST'])
@login_required
def estimate_fare():
    data = request.json
    
    pickup = data.get('pickup', '')
    destination = data.get('destination', '')
    vehicle_type = data.get('vehicle_type', 'standard')
    
    if not pickup or not destination:
        return jsonify({'error': 'Lokasyon gerekli'}), 400
    
    # Mesafe ve süre tahmini (Antalya için)
    distance = random.uniform(2, 25)  # km
    duration = random.randint(10, 60)  # dakika
    
    # Fiyat hesaplama
    base_fare = 15.0
    per_km = 8.5
    per_minute = 1.2
    
    distance_fare = distance * per_km
    time_fare = duration * per_minute
    total = base_fare + distance_fare + time_fare
    
    # Araç tipi çarpanı
    vehicle_multipliers = {
        'standard': 1.0,
        'comfort': 1.3,
        'premium': 1.7,
        'van': 2.0
    }
    
    multiplier = vehicle_multipliers.get(vehicle_type, 1.0)
    total *= multiplier
    
    # Minimum ücret
    total = max(total, 30.0)
    
    return jsonify({
        'success': True,
        'estimated': {
            'distance_km': round(distance, 2),
            'duration_min': duration,
            'fare': round(total, 2),
            'vehicle_type': vehicle_type,
            'base_fare': base_fare,
            'distance_fare': round(distance_fare, 2),
            'time_fare': round(time_fare, 2)
        }
    })

@api.route('/book', methods=['POST'])
@login_required
def book_trip():
    data = request.json
    
    # Gerekli alanlar
    required = ['pickup', 'destination', 'vehicle_type']
    for field in required:
        if not data.get(field):
            return jsonify({'error': f'{field} alanı gereklidir'}), 400
    
    # Yeni yolculuk oluştur
    import string
    trip_code = 'ANT' + ''.join(random.choices(string.digits, k=7))
    
    # Mesafe ve fiyat tahmini
    distance = random.uniform(2, 25)
    duration = random.randint(10, 60)
    
    base_fare = 15.0
    per_km = 8.5
    per_minute = 1.2
    
    distance_fare = distance * per_km
    time_fare = duration * per_minute
    total = base_fare + distance_fare + time_fare
    
    # Araç tipi çarpanı
    vehicle_multipliers = {'standard': 1.0, 'comfort': 1.3, 'premium': 1.7, 'van': 2.0}
    multiplier = vehicle_multipliers.get(data['vehicle_type'], 1.0)
    total *= multiplier
    total = max(total, 30.0)
    
    trip = Trip(
        trip_code=trip_code,
        passenger_id=current_user.id,
        pickup_address=data['pickup'],
        destination_address=data['destination'],
        distance_km=round(distance, 2),
        estimated_duration=duration,
        estimated_fare=round(total, 2),
        vehicle_type=data['vehicle_type'],
        status='searching'  # Sürücü aranıyor
    )
    
    db.session.add(trip)
    db.session.commit()
    
    # Yakındaki sürücüleri bul (simülasyon)
    available_drivers = Driver.query.filter_by(is_available=True, is_online=True).limit(3).all()
    
    return jsonify({
        'success': True,
        'message': 'Rezervasyonunuz alındı. Sürücü aranıyor...',
        'trip': {
            'id': trip.id,
            'code': trip.trip_code,
            'pickup': trip.pickup_address,
            'destination': trip.destination_address,
            'estimated_fare': trip.estimated_fare,
            'estimated_duration': f"{trip.estimated_duration} dakika",
            'status': trip.status,
            'available_drivers': len(available_drivers)
        }
    })

@api.route('/trips/active')
@login_required
def active_trips():
    if current_user.user_type == 'driver':
        driver = Driver.query.filter_by(user_id=current_user.id).first()
        trips = Trip.query.filter_by(driver_id=driver.id).filter(
            Trip.status.in_(['accepted', 'arrived', 'ongoing'])
        ).all()
    else:
        trips = Trip.query.filter_by(passenger_id=current_user.id).filter(
            Trip.status.in_(['searching', 'accepted', 'arrived', 'ongoing'])
        ).all()
    
    return jsonify([{
        'id': t.id,
        'code': t.trip_code,
        'pickup': t.pickup_address,
        'destination': t.destination_address,
        'fare': t.estimated_fare,
        'status': t.status,
        'vehicle_type': t.vehicle_type,
        'created_at': t.created_at.strftime('%H:%M')
    } for t in trips])

@api.route('/stats')
@login_required
def stats():
    if current_user.user_type == 'admin':
        total_trips = Trip.query.count()
        completed_trips = Trip.query.filter_by(status='completed').count()
        total_revenue = db.session.query(db.func.sum(Trip.estimated_fare)).filter_by(status='completed').scalar() or 0
    elif current_user.user_type == 'driver':
        driver = Driver.query.filter_by(user_id=current_user.id).first()
        total_trips = Trip.query.filter_by(driver_id=driver.id).count()
        completed_trips = Trip.query.filter_by(driver_id=driver.id, status='completed').count()
        total_revenue = db.session.query(db.func.sum(Trip.estimated_fare)).filter_by(
            driver_id=driver.id, status='completed'
        ).scalar() or 0
    else:
        total_trips = Trip.query.filter_by(passenger_id=current_user.id).count()
        completed_trips = Trip.query.filter_by(passenger_id=current_user.id, status='completed').count()
        total_revenue = 0  # Yolcular için gelir gösterilmez
    
    return jsonify({
        'total_trips': total_trips,
        'completed_trips': completed_trips,
        'total_revenue': round(total_revenue, 2),
        'avg_fare': round(total_revenue / completed_trips if completed_trips > 0 else 0, 2)
    })

# ========== KONUM API ==========
@api.route('/districts')
def districts():
    # Antalya ilçeleri
    districts = [
        'Muratpaşa', 'Konyaaltı', 'Kepez', 'Döşemealtı', 
        'Aksu', 'Serik', 'Manavgat', 'Alanya', 'Kemer', 'Finike'
    ]
    return jsonify({'districts': districts})

@api.route('/neighborhoods')
def neighborhoods():
    district = request.args.get('district', '')
    
    # Örnek mahalleler (gerçek uygulamada veritabanından gelir)
    neighborhoods_map = {
        'Muratpaşa': ['Fener', 'Lara', 'Meltem', 'Şirinyalı', 'Yeşilbahçe', 'Bahçelievler'],
        'Konyaaltı': ['Arapsuyu', 'Limak', 'Liman', 'Altınkum', 'Gürsu'],
        'Kepez': ['Çallı', 'Erenköy', 'Hacıhaliller', 'Sütçüler', 'Yeni Doğan'],
        'Döşemealtı': ['Akkayalar', 'Çığlık', 'Dağbeli', 'Kovanlık', 'Yeşilbayır']
    }
    
    neighborhoods = neighborhoods_map.get(district, [])
    return jsonify({'neighborhoods': neighborhoods})

@api.route('/streets')
def streets():
    # Örnek caddeler
    streets = [
        'Atatürk Bulvarı', 'Dumlupınar Bulvarı', 'Fevzi Çakmak Caddesi',
        'Lara Caddesi', 'Meltem Caddesi', 'Şirinyalı Caddesi',
        'Çallı Caddesi', 'Erenköy Caddesi', 'Konyaaltı Caddesi'
    ]
    return jsonify({'streets': streets})

@api.route('/vehicle-types')
def vehicle_types():
    types = {
        'standard': {'name': 'Standart', 'multiplier': 1.0, 'icon': '🚗', 'description': 'Ekonomik seyahat'},
        'comfort': {'name': 'Konfor', 'multiplier': 1.3, 'icon': '🚙', 'description': 'Daha geniş ve konforlu'},
        'premium': {'name': 'Premium', 'multiplier': 1.7, 'icon': '🚘', 'description': 'Lüks araçlar'},
        'van': {'name': 'Van', 'multiplier': 2.0, 'icon': '🚐', 'description': 'Geniş bagaj ve 7 kişi'}
    }
    return jsonify({'types': types})

# ========== KULLANICI API ==========
@api.route('/user/profile')
@login_required
def user_profile():
    user_data = {
        'id': current_user.id,
        'email': current_user.email,
        'phone': current_user.phone,
        'first_name': current_user.first_name,
        'last_name': current_user.last_name,
        'full_name': f"{current_user.first_name} {current_user.last_name}",
        'user_type': current_user.user_type,
        'created_at': current_user.created_at.strftime('%d.%m.%Y')
    }
    
    if current_user.user_type == 'driver':
        driver = Driver.query.filter_by(user_id=current_user.id).first()
        if driver:
            user_data.update({
                'driver_id': driver.id,
                'license_number': driver.license_number,
                'car_plate': driver.car_plate,
                'car_model': driver.car_model,
                'car_color': driver.car_color,
                'rating': driver.rating,
                'is_online': driver.is_online,
                'is_available': driver.is_available,
                'total_trips': driver.total_trips
            })
    
    return jsonify(user_data)

@api.route('/user/update-profile', methods=['POST'])
@login_required
def update_profile():
    data = request.json
    
    # Sadece bazı alanları güncellemeye izin ver
    updatable_fields = ['first_name', 'last_name', 'phone']
    
    for field in updatable_fields:
        if field in data:
            setattr(current_user, field, data[field])
    
    # Eğer sürücü ise driver bilgilerini de güncelle
    if current_user.user_type == 'driver':
        driver = Driver.query.filter_by(user_id=current_user.id).first()
        if driver:
            driver_fields = ['car_model', 'car_color', 'car_year']
            for field in driver_fields:
                if field in data:
                    setattr(driver, field, data[field])
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'message': 'Profil başarıyla güncellendi'
    })

# ========== SÜRÜCÜ API ==========
@api.route('/driver/set-online', methods=['POST'])
@login_required
def set_driver_online():
    if current_user.user_type != 'driver':
        return jsonify({'error': 'Sadece sürücüler bu işlemi yapabilir'}), 403
    
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        return jsonify({'error': 'Sürücü profiliniz bulunamadı'}), 404
    
    data = request.json
    is_online = data.get('is_online', False)
    
    driver.is_online = is_online
    driver.is_available = is_online
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'is_online': driver.is_online,
        'is_available': driver.is_available
    })

@api.route('/driver/available-trips')
@login_required
def available_trips():
    if current_user.user_type != 'driver':
        return jsonify({'error': 'Yetkisiz erişim'}), 403
    
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver or not driver.is_online:
        return jsonify({'trips': []})
    
    # Sürücünün araç tipine uygun yolculukları getir
    trips = Trip.query.filter_by(
        status='searching',
        vehicle_type=driver.vehicle_type if hasattr(driver, 'vehicle_type') else 'standard'
    ).order_by(Trip.created_at.desc()).limit(10).all()
    
    return jsonify([{
        'id': t.id,
        'code': t.trip_code,
        'pickup': t.pickup_address,
        'destination': t.destination_address,
        'distance': t.distance_km,
        'fare': t.estimated_fare,
        'passenger_name': t.passenger.first_name if t.passenger else 'Bilinmiyor',
        'created_at': t.created_at.strftime('%H:%M')
    } for t in trips])

# ========== TEST ROUTES ==========
@api.route('/test-auth')
def test_auth():
    return jsonify({
        'authenticated': current_user.is_authenticated,
        'user_id': current_user.id if current_user.is_authenticated else None,
        'user_type': current_user.user_type if current_user.is_authenticated else None
    })

@main.route('/test')
def test_page():
    return "Test sayfası çalışıyor!"