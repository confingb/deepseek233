﻿from flask import render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from app.auth import bp
from app.models import User
from app import db

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.check_password(password):
            if user.is_active:
                login_user(user, remember=True)
                flash('Başarıyla giriş yaptınız!', 'success')
                
                # Kullanıcı tipine göre yönlendirme
                if user.user_type == 'passenger':
                    return redirect(url_for('passenger.dashboard'))
                else:
                    return redirect(url_for('driver.dashboard'))
            else:
                flash('Hesabınız aktif değil!', 'danger')
        else:
            flash('Email veya şifre hatalı!', 'danger')
    
    return render_template('auth/login.html')

@bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        name = request.form.get('name')
        phone = request.form.get('phone')
        user_type = request.form.get('user_type', 'passenger')
        
        # Email kontrolü
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('Bu email zaten kayıtlı!', 'danger')
            return redirect(url_for('auth.register'))
        
        # Yeni kullanıcı oluştur
        user = User(
            email=email,
            name=name,
            phone=phone,
            user_type=user_type
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Kayıt başarılı! Giriş yapabilirsiniz.', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/register.html')

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Çıkış yaptınız!', 'info')
    return redirect(url_for('main.index'))
