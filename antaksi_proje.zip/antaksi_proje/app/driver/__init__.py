﻿from flask import Blueprint

bp = Blueprint('driver', __name__, template_folder='templates')

from app.driver import routes
