from flask import Blueprint, render_template, jsonify, request, flash, redirect, url_for
from flask_login import login_required, current_user
from app import db
from app.models import User, Driver, Trip
from datetime import datetime, timedelta
import json

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.before_request
def check_admin():
    if not current_user.is_authenticated or current_user.user_type != 'admin':
        return redirect(url_for('main.index'))

@admin_bp.route('/dashboard')
@login_required
def dashboard():
    # İstatistikler
    total_users = User.query.count()
    total_drivers = Driver.query.count()
    total_trips = Trip.query.count()
    
    # Bugünkü yolculuklar
    today = datetime.utcnow().date()
    today_trips = Trip.query.filter(db.func.date(Trip.created_at) == today).count()
    
    # Aktif sürücüler
    active_drivers = Driver.query.filter_by(is_online=True).count()
    
    # Gelir istatistikleri
    total_revenue = db.session.query(db.func.sum(Trip.actual_fare)).filter(
        Trip.status == 'completed',
        Trip.payment_status == 'completed'
    ).scalar() or 0
    
    # Son 7 günün yolculukları
    last_week = datetime.utcnow() - timedelta(days=7)
    weekly_trips = Trip.query.filter(Trip.created_at >= last_week).count()
    
    return render_template('admin/dashboard.html',
                         total_users=total_users,
                         total_drivers=total_drivers,
                         total_trips=total_trips,
                         today_trips=today_trips,
                         active_drivers=active_drivers,
                         total_revenue=total_revenue,
                         weekly_trips=weekly_trips)

@admin_bp.route('/users')
@login_required
def users():
    users_list = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin/users.html', users=users_list)

@admin_bp.route('/drivers')
@login_required
def drivers():
    drivers_list = Driver.query.join(User).order_by(User.created_at.desc()).all()
    return render_template('admin/drivers.html', drivers=drivers_list)

@admin_bp.route('/trips')
@login_required
def trips():
    trips_list = Trip.query.order_by(Trip.created_at.desc()).limit(100).all()
    return render_template('admin/trips.html', trips=trips_list)

# API Endpoints
@admin_bp.route('/api/stats')
@login_required
def stats():
    # Günlük yolculuk istatistikleri
    days = 30
    date_counts = {}
    
    for i in range(days):
        date = (datetime.utcnow() - timedelta(days=i)).date()
        count = Trip.query.filter(db.func.date(Trip.created_at) == date).count()
        date_counts[date.strftime('%d.%m')] = count
    
    # Kullanıcı tipi dağılımı
    user_types = {
        'passenger': User.query.filter_by(user_type='passenger').count(),
        'driver': User.query.filter_by(user_type='driver').count(),
        'admin': User.query.filter_by(user_type='admin').count()
    }
    
    return jsonify({
        'daily_trips': date_counts,
        'user_types': user_types,
        'revenue_by_day': get_revenue_by_day(days)
    })

@admin_bp.route('/api/user/<int:user_id>/toggle-active', methods=['POST'])
@login_required
def toggle_user_active(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'Kullanıcı bulunamadı'}), 404
    
    user.is_active = not user.is_active
    db.session.commit()
    
    return jsonify({
        'success': True,
        'is_active': user.is_active,
        'message': f'Kullanıcı {"aktif" if user.is_active else "pasif"} yapıldı'
    })

@admin_bp.route('/api/driver/<int:driver_id>/toggle-approve', methods=['POST'])
@login_required
def toggle_driver_approve(driver_id):
    driver = Driver.query.get(driver_id)
    if not driver:
        return jsonify({'error': 'Sürücü bulunamadı'}), 404
    
    driver.approved = not driver.approved
    db.session.commit()
    
    return jsonify({
        'success': True,
        'approved': driver.approved,
        'message': f'Sürücü {"onaylandı" if driver.approved else "onayı kaldırıldı"}'
    })

@admin_bp.route('/api/trip/<int:trip_id>/details')
@login_required
def trip_details(trip_id):
    trip = Trip.query.get(trip_id)
    if not trip:
        return jsonify({'error': 'Yolculuk bulunamadı'}), 404
    
    trip_data = {
        'id': trip.id,
        'code': trip.trip_code,
        'passenger': trip.passenger.get_full_name() if trip.passenger else 'Bilinmiyor',
        'driver': trip.assigned_driver.user.get_full_name() if trip.assigned_driver else 'Atanmadı',
        'pickup': trip.pickup_address,
        'destination': trip.destination_address,
        'distance': trip.distance_km,
        'duration': trip.estimated_duration,
        'fare': trip.actual_fare or trip.estimated_fare,
        'status': trip.status,
        'payment_status': trip.payment_status,
        'created_at': trip.created_at.strftime('%d.%m.%Y %H:%M'),
        'vehicle_type': trip.vehicle_type
    }
    
    return jsonify(trip_data)

def get_revenue_by_day(days=30):
    revenue_data = {}
    
    for i in range(days):
        date = (datetime.utcnow() - timedelta(days=i)).date()
        revenue = db.session.query(db.func.sum(Trip.actual_fare)).filter(
            db.func.date(Trip.completed_at) == date,
            Trip.status == 'completed',
            Trip.payment_status == 'completed'
        ).scalar() or 0
        
        revenue_data[date.strftime('%d.%m')] = float(revenue)
    
    return revenue_data