﻿from flask import Blueprint

bp = Blueprint('passenger', __name__, template_folder='templates')

from app.passenger import routes
